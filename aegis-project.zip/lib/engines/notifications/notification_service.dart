// AEGIS — Notification service (real flutter_local_notifications).
//
// Schedules reminder notifications at exact times using the local timezone.
// Safe to call before init (init() is idempotent and guarded).

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

class NotificationService {
  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  Future<void> initialize() async {
    if (_initialized) return;
    tzdata.initializeTimeZones();

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await _plugin.initialize(settings);

    // Request runtime notification permission on Android 13+.
    final androidImpl = _plugin.resolvePlatformSpecificImplementation<
        AndroidFlutterLocalNotificationsPlugin>();
    await androidImpl?.requestNotificationsPermission();

    _initialized = true;
  }

  Future<void> schedule({
    required int id,
    required String title,
    required String body,
    required DateTime when,
  }) async {
    if (!_initialized) await initialize();
    // Guard against past times.
    final target = when.isBefore(DateTime.now())
        ? DateTime.now().add(const Duration(seconds: 5))
        : when;

    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'aegis_reminders',
        'AEGIS Reminders',
        channelDescription: 'Scheduled reminders from AEGIS',
        importance: Importance.high,
        priority: Priority.high,
      ),
    );

    await _plugin.zonedSchedule(
      id,
      title,
      body,
      tz.TZDateTime.from(target, tz.local),
      details,
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
    );
  }

  Future<void> showNow(String title, String body) async {
    if (!_initialized) await initialize();
    const details = NotificationDetails(
      android: AndroidNotificationDetails(
        'aegis_general',
        'AEGIS',
        importance: Importance.defaultImportance,
      ),
    );
    await _plugin.show(DateTime.now().millisecond, title, body, details);
  }

  Future<void> cancel(int id) async {
    if (!_initialized) return;
    await _plugin.cancel(id);
  }
}
