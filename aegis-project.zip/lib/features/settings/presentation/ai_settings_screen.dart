// AEGIS — Settings: API key, model, verify connection, voice toggle.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/di/providers.dart';
import '../../../core/theme/aegis_theme.dart';

class AiSettingsScreen extends ConsumerStatefulWidget {
  const AiSettingsScreen({super.key});
  @override
  ConsumerState<AiSettingsScreen> createState() => _AiSettingsScreenState();
}

class _AiSettingsScreenState extends ConsumerState<AiSettingsScreen> {
  final _keyCtrl = TextEditingController();
  final _urlCtrl = TextEditingController();
  bool _busy = false;
  String? _status;
  bool _loaded = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final s = ref.read(settingsRepositoryProvider);
    _keyCtrl.text = (await s.get('openai_api_key')) ?? '';
    _urlCtrl.text = (await s.get('openai_base_url')) ?? '';
    if (mounted) setState(() => _loaded = true);
  }

  @override
  void dispose() {
    _keyCtrl.dispose();
    _urlCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    setState(() { _busy = true; _status = null; });
    final s = ref.read(settingsRepositoryProvider);
    await s.set('openai_api_key', _keyCtrl.text.trim());
    await s.set('openai_base_url', _urlCtrl.text.trim());
    ref.invalidate(aiProviderProvider);

    final provider = await ref.read(aiProviderProvider.future);
    final ok = provider != null && await provider.isAvailable();
    if (!mounted) return;
    setState(() {
      _busy = false;
      _status = ok ? 'Connected. AEGIS is ready.' : 'Saved, but could not verify the key.';
    });
  }

  @override
  Widget build(BuildContext context) {
    final model = ref.watch(selectedModelProvider);
    if (!_loaded) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    return Scaffold(
      appBar: AppBar(title: const Text('Settings'), backgroundColor: Colors.transparent),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text('AI Provider', style: TextStyle(fontSize: 18, color: AegisColors.textPrimary)),
          const SizedBox(height: 6),
          const Text(
            'AEGIS works with OpenAI and any OpenAI-compatible endpoint. Your key '
            'is encrypted and stored only on this device.',
            style: TextStyle(color: AegisColors.textMuted, fontSize: 13, height: 1.4),
          ),
          const SizedBox(height: 16),
          TextField(controller: _keyCtrl, obscureText: true, decoration: const InputDecoration(labelText: 'API key', hintText: 'sk-…', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          TextField(controller: _urlCtrl, decoration: const InputDecoration(labelText: 'Base URL (optional)', hintText: 'https://api.openai.com/v1', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: model,
            decoration: const InputDecoration(labelText: 'Model', border: OutlineInputBorder()),
            items: const [
              DropdownMenuItem(value: 'gpt-4o-mini', child: Text('AEGIS-Fast (4o-mini)')),
              DropdownMenuItem(value: 'gpt-4o', child: Text('AEGIS-Core (4o)')),
            ],
            onChanged: (v) { if (v != null) ref.read(selectedModelProvider.notifier).state = v; },
          ),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: _busy ? null : _save,
            child: _busy
                ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                : const Text('Save & verify'),
          ),
          if (_status != null) ...[
            const SizedBox(height: 12),
            Text(_status!, style: TextStyle(color: _status!.startsWith('Connected') ? AegisColors.stateOk : AegisColors.stateWarn)),
          ],
          const Divider(height: 40),
          const Text('About', style: TextStyle(fontSize: 18, color: AegisColors.textPrimary)),
          const SizedBox(height: 8),
          const Text('AEGIS — original JARVIS-inspired assistant. All data encrypted at rest.',
              style: TextStyle(color: AegisColors.textMuted, fontSize: 13)),
        ],
      ),
    );
  }
}
