// AEGIS — central dependency injection (Riverpod).
//
// Single source of truth wiring services + repositories. Everything the UI
// needs hangs off these providers. Bootstrap (crypto, notifications, db) is
// awaited once in appBootstrapProvider before the shell renders.

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../data/repositories/chat_repository.dart';
import '../../data/repositories/notes_repository.dart';
import '../../data/repositories/reminders_repository.dart';
import '../../data/repositories/settings_repository.dart';
import '../../data/repositories/tasks_repository.dart';
import '../../engines/ai/ai_provider.dart';
import '../../engines/ai/providers/openai_provider.dart';
import '../../engines/conversation/conversation_orchestrator.dart';
import '../../engines/memory/memory_service.dart';
import '../../engines/notifications/notification_service.dart';
import '../../engines/security/crypto_service.dart';
import '../../engines/voice/voice_engine.dart';
import '../../core/permissions/mic_permission_service.dart';

// ---- singletons ----
final cryptoServiceProvider = Provider<CryptoService>((ref) => CryptoService());
final notificationServiceProvider =
    Provider<NotificationService>((ref) => NotificationService());

/// One-time async bootstrap. The shell watches this and shows a splash until ok.
final appBootstrapProvider = FutureProvider<bool>((ref) async {
  await ref.read(cryptoServiceProvider).initialize();
  await ref.read(notificationServiceProvider).initialize();
  return true;
});

// ---- repositories ----
final settingsRepositoryProvider =
    Provider<SettingsRepository>((ref) => SettingsRepository(ref.read(cryptoServiceProvider)));
final notesRepositoryProvider =
    Provider<NotesRepository>((ref) => NotesRepository(ref.read(cryptoServiceProvider)));
final tasksRepositoryProvider =
    Provider<TasksRepository>((ref) => TasksRepository(ref.read(cryptoServiceProvider)));
final remindersRepositoryProvider = Provider<RemindersRepository>((ref) =>
    RemindersRepository(ref.read(cryptoServiceProvider), ref.read(notificationServiceProvider)));
final chatRepositoryProvider =
    Provider<ChatRepository>((ref) => ChatRepository(ref.read(cryptoServiceProvider)));

// ---- AI config ----
final selectedModelProvider = StateProvider<String>((ref) => 'gpt-4o-mini');

/// Loads the stored API key + base URL and builds the provider, or null if
/// no key is configured yet. Rebuilds when the key is saved (via invalidate).
final aiProviderProvider = FutureProvider<AiProvider?>((ref) async {
  final settings = ref.read(settingsRepositoryProvider);
  final key = await settings.get('openai_api_key');
  if (key == null || key.isEmpty) return null;
  final baseUrl = await settings.get('openai_base_url');
  return OpenAiProvider(
    apiKey: key,
    baseUrl: (baseUrl == null || baseUrl.isEmpty) ? 'https://api.openai.com/v1' : baseUrl,
  );
});

// ---- voice ----
final micPermissionProvider =
    Provider<MicPermissionService>((ref) => MicPermissionServiceImpl());

final voiceEngineProvider = Provider<VoiceEngine>((ref) {
  final engine = VoiceEngine(permissions: ref.read(micPermissionProvider));
  ref.onDispose(engine.dispose);
  return engine;
});

// ---- memory + orchestrator ----
final memoryServiceProvider = FutureProvider<MemoryService?>((ref) async {
  final provider = await ref.watch(aiProviderProvider.future);
  if (provider == null) return null;
  return MemoryService(provider: provider, modelId: ref.watch(selectedModelProvider));
});

/// The conversation engine. Persists turns to the active conversation.
final activeConversationIdProvider = StateProvider<String?>((ref) => null);

final orchestratorProvider = FutureProvider<ConversationOrchestrator?>((ref) async {
  final provider = await ref.watch(aiProviderProvider.future);
  final memory = await ref.watch(memoryServiceProvider.future);
  if (provider == null || memory == null) return null;

  final chat = ref.read(chatRepositoryProvider);
  final voice = ref.read(voiceEngineProvider);

  final orch = ConversationOrchestrator(
    voice: voice,
    provider: provider,
    memory: memory,
    modelId: ref.watch(selectedModelProvider),
    onPersist: (role, content) async {
      var convId = ref.read(activeConversationIdProvider);
      if (convId == null) {
        final conv = await chat.createConversation('Conversation');
        convId = conv.id;
        ref.read(activeConversationIdProvider.notifier).state = convId;
      }
      await chat.addMessage(ChatMessageFactory.make(convId, role, content));
    },
  );
  ref.onDispose(orch.dispose);
  return orch;
});
