# Get the AEGIS APK on your tablet — NO computer needed

Everything below is done **from your tablet's browser**. A free cloud server
builds the APK for you; you just download and install it.

Total time: ~15 min the first time. Later rebuilds: ~5 min, fully automatic.

---

## What you need
- Your Android tablet (that's it)
- A **free GitHub account** → sign up at https://github.com/signup
- The file **`aegis-project.zip`** (in this workspace — download it to your tablet)

---

## STEP 1 — Create a GitHub repository (2 min)
1. On your tablet, open https://github.com in a browser (Chrome works well).
   Tip: request the **desktop site** (browser menu → "Desktop site") — the
   upload buttons are easier to reach.
2. Tap **+** (top right) → **New repository**.
3. Name it `aegis` (anything is fine).
4. Choose **Public** (free CI minutes) → tap **Create repository**.

---

## STEP 2 — Upload the project ZIP contents (5 min)
GitHub can't unzip for you, so we upload the extracted files. Two easy options:

### Option A — Upload the folder (simplest)
1. On your tablet, use a file manager (e.g. **Files by Google**) to **extract**
   `aegis-project.zip`. You'll get a folder `aegis-project` with everything
   inside.
2. Back on the GitHub repo page, tap **Add file** → **Upload files**.
3. Tap **choose your files**, then select **all** the extracted files and
   folders. (Most mobile browsers let you multi-select; if it only allows a
   folder, select the folder.)
4. Scroll down, tap **Commit changes**.

### Option B — If multi-select is awkward on your browser
Use the **GitHub mobile app** (Play Store) OR an app like **"MGit"** /
**"Termux"** to push the folder. Option A works for most people; only use this
if A is fussy.

> Important: the hidden folder **`.github`** must be uploaded too (it contains
> the build recipe). If your file manager hides dot-folders, enable
> "show hidden files" before selecting.

---

## STEP 3 — The cloud build starts automatically (5 min, hands-off)
The moment your files land on GitHub, the build kicks off.
1. On the repo page, tap the **Actions** tab.
2. You'll see a run called **"Build AEGIS APK"** with a spinning yellow dot.
3. Wait until it turns into a **green check** (~4–6 minutes).
   - If it's red, open it, read the error, and send it to me — I'll fix it.

---

## STEP 4 — Download your APK (1 min)
Two places to get it (either works):

**A) From Releases (easiest tap-to-download):**
1. On the repo page tap **Releases** (right side, or `/releases` in the URL).
2. Open the newest **"AEGIS build N"**.
3. Under **Assets**, tap **app-release.apk** → it downloads to your tablet.

**B) From the Actions run:**
1. Open the green build run in **Actions**.
2. Scroll to **Artifacts** → tap **aegis-release-apk** to download (it comes as
   a .zip containing the .apk — extract it).

---

## STEP 5 — Install on your tablet (1 min)
1. Open the downloaded **app-release.apk** (via Files or the download notice).
2. Android will ask to allow installing from this source → tap **Settings** →
   enable **Allow from this source** → go back → **Install**.
3. Open **AEGIS**.

---

## STEP 6 — First run
1. Go to **Settings** → paste your **OpenAI (or compatible) API key** →
   **Save & verify**.
2. **Chat** to type, or **Voice** to talk (grant the mic permission).
3. **Tasks / Notes / Reminders** work offline, no key needed.

---

## Rebuilding later (after any change)
You never touch a computer again:
- Edit a file directly on GitHub (pencil icon) **or** upload new files, commit.
- The build reruns automatically → new APK appears in **Releases**.
- You can also trigger it by hand: **Actions** tab → **Build AEGIS APK** →
  **Run workflow**.

---

## If a build fails
Open the red run in **Actions**, tap the failed step to see the log, copy the
error text, and paste it to me. Cloud build errors are usually a one-line fix
(a dependency version), and I'll turn it around fast.

## Why this works with no PC
GitHub Actions gives you a free Linux server that installs Flutter, builds the
APK, and hands it back as a downloadable file. Your tablet only ever uploads
text files and downloads one APK — no SDK, no Android Studio, no computer.
