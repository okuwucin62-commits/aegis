package ai.aegis.app

import io.flutter.embedding.android.FlutterActivity

/**
 * AEGIS host activity.
 *
 * Kept minimal: the Flutter engine drives the UI. Native platform channels
 * (wake-word foreground service, etc.) are registered here in later milestones.
 */
class MainActivity : FlutterActivity()
