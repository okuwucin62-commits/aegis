// AEGIS — domain entities for conversation & memory. Pure Dart, no deps.

import '../../engines/ai/ai_provider.dart';

/// A durable turn in a conversation (persisted, unlike transient stream chunks).
class Turn {
  final String id;
  final AiRole role;
  final String content;
  final DateTime at;

  const Turn({
    required this.id,
    required this.role,
    required this.content,
    required this.at,
  });

  AiMessage toAiMessage() => AiMessage(role: role, content: content);
}

/// A retrieved long-term memory, ranked for relevance.
class MemoryHit {
  final String id;
  final String content;
  final double score; // hybrid relevance 0..1
  final DateTime createdAt;

  const MemoryHit({
    required this.id,
    required this.content,
    required this.score,
    required this.createdAt,
  });
}

/// Kinds of long-term memory (matches DB `memory_items.kind`).
enum MemoryKind { fact, preference, event, summary }
