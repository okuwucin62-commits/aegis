// AEGIS — root widget. Theme + adaptive shell.

import 'package:flutter/material.dart';

import 'core/theme/aegis_theme.dart';
import 'features/shell/app_shell.dart';

class AegisApp extends StatelessWidget {
  const AegisApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AEGIS',
      debugShowCheckedModeBanner: false,
      theme: AegisTheme.dark(),
      home: const AppShell(),
    );
  }
}
