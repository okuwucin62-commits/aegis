// AEGIS — Dashboard hub. AI orb, status, quick actions, device info.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/di/providers.dart';
import '../../../core/theme/aegis_theme.dart';
import '../../../engines/device/device_info_service.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key, required this.onNavigate});
  final ValueChanged<int> onNavigate;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final aiReady = ref.watch(aiProviderProvider).valueOrNull != null;

    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              const Text('AEGIS', style: TextStyle(fontSize: 30, letterSpacing: 8, color: AegisColors.textPrimary)),
              _StatusChip(online: aiReady),
            ]),
            const Text('YOUR AI ASSISTANT', style: TextStyle(fontSize: 11, letterSpacing: 2, color: AegisColors.textMuted)),
            const SizedBox(height: 28),

            Center(child: _Orb()),
            const SizedBox(height: 12),
            Center(
              child: Text(aiReady ? 'Standing by' : 'Add an API key to activate',
                  style: const TextStyle(color: AegisColors.neonPrimary, letterSpacing: 2)),
            ),
            const SizedBox(height: 28),

            const Text('QUICK ACTIONS', style: TextStyle(fontSize: 12, letterSpacing: 2, color: AegisColors.textMuted)),
            const SizedBox(height: 12),
            Wrap(spacing: 12, runSpacing: 12, children: [
              _Action(icon: Icons.mic, label: 'Talk', onTap: () => onNavigate(1)),
              _Action(icon: Icons.chat, label: 'Chat', onTap: () => onNavigate(2)),
              _Action(icon: Icons.check_circle_outline, label: 'Tasks', onTap: () => onNavigate(3)),
              _Action(icon: Icons.notes, label: 'Notes', onTap: () => onNavigate(4)),
              _Action(icon: Icons.alarm, label: 'Reminders', onTap: () => onNavigate(5)),
              _Action(icon: Icons.settings, label: 'Settings', onTap: () => onNavigate(6)),
            ]),

            const SizedBox(height: 28),
            const Text('DEVICE', style: TextStyle(fontSize: 12, letterSpacing: 2, color: AegisColors.textMuted)),
            const SizedBox(height: 8),
            _DeviceCard(),
          ]),
        ),
      ),
    );
  }
}

class _StatusChip extends StatelessWidget {
  const _StatusChip({required this.online});
  final bool online;
  @override
  Widget build(BuildContext context) {
    final c = online ? AegisColors.stateOk : AegisColors.stateWarn;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: c.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: c.withValues(alpha: 0.4)),
      ),
      child: Text(online ? 'AI Online' : 'Setup needed', style: TextStyle(color: c, fontSize: 12)),
    );
  }
}

class _Orb extends StatefulWidget {
  @override
  State<_Orb> createState() => _OrbState();
}

class _OrbState extends State<_Orb> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1800))..repeat(reverse: true);
  @override
  void dispose() { _c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
        animation: _c,
        builder: (_, __) => Transform.scale(
          scale: 1 + _c.value * 0.07,
          child: Container(
            width: 130, height: 130,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const RadialGradient(colors: [Color(0xFFBFF3FF), AegisColors.neonPrimary, AegisColors.neonSecondary], stops: [0, 0.45, 1]),
              boxShadow: [BoxShadow(color: AegisColors.neonGlow.withValues(alpha: 0.5), blurRadius: 50, spreadRadius: 6)],
            ),
          ),
        ),
      );
}

class _Action extends StatelessWidget {
  const _Action({required this.icon, required this.label, required this.onTap});
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          width: 100, height: 88,
          decoration: BoxDecoration(color: AegisColors.glassFill, borderRadius: BorderRadius.circular(16), border: Border.all(color: AegisColors.glassStroke)),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Icon(icon, color: AegisColors.neonPrimary),
            const SizedBox(height: 8),
            Text(label, style: const TextStyle(color: AegisColors.textPrimary, fontSize: 12)),
          ]),
        ),
      );
}

class _DeviceCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: DeviceInfoService.summary(),
      builder: (context, snap) {
        final info = snap.data ?? 'Reading device info…';
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              const Icon(Icons.tablet_android, color: AegisColors.neonPrimary),
              const SizedBox(width: 12),
              Expanded(child: Text(info, style: const TextStyle(color: AegisColors.textMuted, fontSize: 13))),
            ]),
          ),
        );
      },
    );
  }
}
