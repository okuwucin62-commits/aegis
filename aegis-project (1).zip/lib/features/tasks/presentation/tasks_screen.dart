// AEGIS — Task management: add, cycle status, set priority, delete.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/di/providers.dart';
import '../../../core/theme/aegis_theme.dart';
import '../../../data/repositories/models.dart';

final _tasksProvider = FutureProvider.autoDispose((ref) async {
  return ref.read(tasksRepositoryProvider).all();
});

class TasksScreen extends ConsumerWidget {
  const TasksScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tasks = ref.watch(_tasksProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Tasks'), backgroundColor: Colors.transparent),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _add(context, ref),
        child: const Icon(Icons.add),
      ),
      body: tasks.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('$e')),
        data: (items) => items.isEmpty
            ? const Center(child: Text('No tasks yet. Tap + to add one.', style: TextStyle(color: AegisColors.textMuted)))
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: items.length,
                itemBuilder: (_, i) {
                  final t = items[i];
                  return Card(
                    child: ListTile(
                      leading: IconButton(
                        icon: Icon(_statusIcon(t.status), color: _statusColor(t.status)),
                        onPressed: () async {
                          final next = TaskStatusModel.values[(t.status.index + 1) % 3];
                          await ref.read(tasksRepositoryProvider).update(t.copyWith(status: next));
                          ref.invalidate(_tasksProvider);
                        },
                      ),
                      title: Text(t.title,
                          style: TextStyle(
                            color: AegisColors.textPrimary,
                            decoration: t.status == TaskStatusModel.done ? TextDecoration.lineThrough : null,
                          )),
                      subtitle: Text(
                        '${_priorityLabel(t.priority)}${t.dueAt != null ? ' · due ${t.dueAt!.month}/${t.dueAt!.day}' : ''}',
                        style: const TextStyle(color: AegisColors.textMuted, fontSize: 12),
                      ),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline, color: AegisColors.textMuted),
                        onPressed: () async {
                          await ref.read(tasksRepositoryProvider).delete(t.id);
                          ref.invalidate(_tasksProvider);
                        },
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }

  IconData _statusIcon(TaskStatusModel s) => switch (s) {
        TaskStatusModel.todo => Icons.radio_button_unchecked,
        TaskStatusModel.doing => Icons.timelapse,
        TaskStatusModel.done => Icons.check_circle,
      };
  Color _statusColor(TaskStatusModel s) => switch (s) {
        TaskStatusModel.todo => AegisColors.textMuted,
        TaskStatusModel.doing => AegisColors.stateWarn,
        TaskStatusModel.done => AegisColors.stateOk,
      };
  String _priorityLabel(int p) => switch (p) { 2 => 'High priority', 0 => 'Low priority', _ => 'Normal' };

  Future<void> _add(BuildContext context, WidgetRef ref) async {
    final ctrl = TextEditingController();
    var priority = 1;
    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AegisColors.bgElevated,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(ctx).viewInsets.bottom, left: 16, right: 16, top: 16),
        child: StatefulBuilder(
          builder: (ctx, setSheet) => Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: ctrl, autofocus: true, decoration: const InputDecoration(labelText: 'Task')),
            const SizedBox(height: 12),
            SegmentedButton<int>(
              segments: const [
                ButtonSegment(value: 0, label: Text('Low')),
                ButtonSegment(value: 1, label: Text('Normal')),
                ButtonSegment(value: 2, label: Text('High')),
              ],
              selected: {priority},
              onSelectionChanged: (s) => setSheet(() => priority = s.first),
            ),
            const SizedBox(height: 12),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Add task')),
            const SizedBox(height: 16),
          ]),
        ),
      ),
    );
    if (ok == true && ctrl.text.trim().isNotEmpty) {
      await ref.read(tasksRepositoryProvider).create(title: ctrl.text.trim(), priority: priority);
      ref.invalidate(_tasksProvider);
    }
  }
}
