// AEGIS — text chat: streaming AI conversation, persisted to encrypted history.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/di/providers.dart';
import '../../../core/theme/aegis_theme.dart';
import '../../../engines/conversation/conversation_orchestrator.dart';

/// Live streaming assistant text.
final _assistantStreamProvider = StreamProvider.autoDispose<AssistantDelta>((ref) async* {
  final orch = await ref.watch(orchestratorProvider.future);
  if (orch == null) return;
  yield* orch.assistantStream;
});

class ChatScreen extends ConsumerStatefulWidget {
  const ChatScreen({super.key});
  @override
  ConsumerState<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends ConsumerState<ChatScreen> {
  final _ctrl = TextEditingController();
  final _scroll = ScrollController();
  final List<(String role, String text)> _messages = [];
  String _streaming = '';

  @override
  void dispose() {
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = _ctrl.text.trim();
    if (text.isEmpty) return;
    final orch = await ref.read(orchestratorProvider.future);
    if (orch == null) {
      _showNeedsKey();
      return;
    }
    setState(() {
      _messages.add(('user', text));
      _streaming = '';
      _ctrl.clear();
    });
    orch.speakReplies = false; // text mode: don't talk over the user
    await orch.handleUserInput(text);
  }

  void _showNeedsKey() {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Add your AI API key in Settings to start chatting.')));
  }

  @override
  Widget build(BuildContext context) {
    // Fold streaming deltas into the visible transcript.
    ref.listen(_assistantStreamProvider, (_, next) {
      final d = next.valueOrNull;
      if (d == null) return;
      setState(() {
        if (d.isFinal) {
          _messages.add(('assistant', d.fullTextSoFar));
          _streaming = '';
        } else {
          _streaming = d.fullTextSoFar;
        }
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scroll.hasClients) {
          _scroll.animateTo(_scroll.position.maxScrollExtent,
              duration: const Duration(milliseconds: 200), curve: Curves.easeOut);
        }
      });
    });

    final aiReady = ref.watch(aiProviderProvider).valueOrNull != null;

    return Scaffold(
      appBar: AppBar(title: const Text('Chat'), backgroundColor: Colors.transparent),
      body: Column(children: [
        if (!aiReady)
          Container(
            width: double.infinity,
            color: AegisColors.stateWarn.withValues(alpha: 0.12),
            padding: const EdgeInsets.all(10),
            child: const Text('No AI key set — add one in Settings to chat.',
                textAlign: TextAlign.center, style: TextStyle(color: AegisColors.stateWarn, fontSize: 12)),
          ),
        Expanded(
          child: _messages.isEmpty && _streaming.isEmpty
              ? const Center(child: Text('Ask AEGIS anything.', style: TextStyle(color: AegisColors.textMuted)))
              : ListView(
                  controller: _scroll,
                  padding: const EdgeInsets.all(12),
                  children: [
                    ..._messages.map((m) => _Bubble(role: m.$1, text: m.$2)),
                    if (_streaming.isNotEmpty) _Bubble(role: 'assistant', text: _streaming),
                  ],
                ),
        ),
        SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              Expanded(
                child: TextField(
                  controller: _ctrl,
                  onSubmitted: (_) => _send(),
                  decoration: const InputDecoration(
                    hintText: 'Message AEGIS…',
                    border: OutlineInputBorder(),
                    contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              IconButton.filled(onPressed: _send, icon: const Icon(Icons.send)),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.role, required this.text});
  final String role;
  final String text;
  @override
  Widget build(BuildContext context) {
    final me = role == 'user';
    return Align(
      alignment: me ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 4),
        padding: const EdgeInsets.all(12),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
        decoration: BoxDecoration(
          color: me ? AegisColors.neonPrimary.withValues(alpha: 0.18) : AegisColors.glassFill,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AegisColors.glassStroke),
        ),
        child: Text(text, style: const TextStyle(color: AegisColors.textPrimary, height: 1.4)),
      ),
    );
  }
}
