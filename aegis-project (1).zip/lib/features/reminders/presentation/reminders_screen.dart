// AEGIS — Reminders: schedule real local notifications at a chosen time.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/di/providers.dart';
import '../../../core/theme/aegis_theme.dart';

final _remindersProvider = FutureProvider.autoDispose((ref) async {
  return ref.read(remindersRepositoryProvider).all();
});

class RemindersScreen extends ConsumerWidget {
  const RemindersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final reminders = ref.watch(_remindersProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Reminders'), backgroundColor: Colors.transparent),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _add(context, ref),
        child: const Icon(Icons.add_alarm),
      ),
      body: reminders.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('$e')),
        data: (items) => items.isEmpty
            ? const Center(child: Text('No reminders.\nTap + to schedule one.', textAlign: TextAlign.center, style: TextStyle(color: AegisColors.textMuted)))
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: items.length,
                itemBuilder: (_, i) {
                  final r = items[i];
                  final dt = r.remindAt;
                  return Card(
                    child: ListTile(
                      leading: Icon(r.done ? Icons.check_circle : Icons.alarm,
                          color: r.done ? AegisColors.stateOk : AegisColors.neonPrimary),
                      title: Text(r.text,
                          style: TextStyle(
                            color: AegisColors.textPrimary,
                            decoration: r.done ? TextDecoration.lineThrough : null,
                          )),
                      subtitle: Text('${dt.year}-${_2(dt.month)}-${_2(dt.day)}  ${_2(dt.hour)}:${_2(dt.minute)}',
                          style: const TextStyle(color: AegisColors.textMuted, fontSize: 12)),
                      trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                        if (!r.done)
                          IconButton(
                            icon: const Icon(Icons.done, color: AegisColors.stateOk),
                            onPressed: () async {
                              await ref.read(remindersRepositoryProvider).markDone(r);
                              ref.invalidate(_remindersProvider);
                            },
                          ),
                        IconButton(
                          icon: const Icon(Icons.delete_outline, color: AegisColors.textMuted),
                          onPressed: () async {
                            await ref.read(remindersRepositoryProvider).delete(r);
                            ref.invalidate(_remindersProvider);
                          },
                        ),
                      ]),
                    ),
                  );
                },
              ),
      ),
    );
  }

  String _2(int n) => n.toString().padLeft(2, '0');

  Future<void> _add(BuildContext context, WidgetRef ref) async {
    final ctrl = TextEditingController();
    final now = DateTime.now();
    final text = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AegisColors.bgElevated,
        title: const Text('New reminder'),
        content: TextField(controller: ctrl, autofocus: true, decoration: const InputDecoration(hintText: 'Remind me to…')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text.trim()), child: const Text('Next')),
        ],
      ),
    );
    if (text == null || text.isEmpty || !context.mounted) return;

    final date = await showDatePicker(
      context: context,
      firstDate: now,
      lastDate: now.add(const Duration(days: 365 * 2)),
      initialDate: now,
    );
    if (date == null || !context.mounted) return;

    final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(now.add(const Duration(minutes: 5))));
    if (time == null) return;

    final when = DateTime(date.year, date.month, date.day, time.hour, time.minute);
    await ref.read(remindersRepositoryProvider).create(text: text, remindAt: when);
    ref.invalidate(_remindersProvider);
  }
}
