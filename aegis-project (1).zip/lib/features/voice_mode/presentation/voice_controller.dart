// AEGIS — Voice Mode controller. Issues intents to the engine + orchestrator.

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/di/providers.dart';
import '../../../engines/voice/voice_engine.dart';
import '../../../engines/voice/voice_state.dart';
import '../../../engines/conversation/conversation_orchestrator.dart';

/// Live snapshot the UI watches. Initializes the engine so the mic-permission
/// prompt appears when the user opens Voice Mode.
final voiceSnapshotProvider = StreamProvider<VoiceSnapshot>((ref) {
  final engine = ref.watch(voiceEngineProvider);
  engine.initialize();
  // Ensure the orchestrator is built so onUtterance is wired to the AI loop.
  ref.watch(orchestratorProvider);
  return engine.stream;
});

/// Live streaming assistant reply text.
final assistantVoiceStreamProvider = StreamProvider.autoDispose<AssistantDelta>((ref) async* {
  final orch = await ref.watch(orchestratorProvider.future);
  if (orch == null) return;
  yield* orch.assistantStream;
});

final voiceControllerProvider =
    NotifierProvider<VoiceController, void>(VoiceController.new);

class VoiceController extends Notifier<void> {
  @override
  void build() {}

  VoiceEngine get _engine => ref.read(voiceEngineProvider);

  Future<void> toggleListening() async {
    final s = _engine.current;
    if (s.status == VoiceStatus.listening) {
      await _engine.stopListening();
      return;
    }
    final orch = await ref.read(orchestratorProvider.future);
    if (orch != null) {
      orch.speakReplies = true; // voice mode: speak answers aloud
      await orch.onUserWantsToSpeak();
    } else {
      await _engine.startListening(); // no AI key: still show mic working
    }
  }

  Future<void> startPushToTalk() => toggleListening();
  Future<void> endPushToTalk() => _engine.stopListening();
  Future<void> retry() => _engine.initialize();
  Future<void> openSettings() => ref.read(micPermissionProvider).openSettingsPage();
}
