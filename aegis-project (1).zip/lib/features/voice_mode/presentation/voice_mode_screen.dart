// AEGIS — Voice Mode screen.
//
// Renders the AI orb + a clear 4-state status indicator (Idle / Listening /
// Processing / Speaking), a live amplitude waveform, the running transcript,
// and explicit, actionable error UI (retry, open settings).

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/theme/aegis_theme.dart';
import '../../../engines/voice/voice_state.dart';
import 'voice_controller.dart';

class VoiceModeScreen extends ConsumerWidget {
  const VoiceModeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(voiceSnapshotProvider);
    final ctrl = ref.read(voiceControllerProvider.notifier);

    final snap = async.value ?? const VoiceSnapshot();

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _StatusBadge(status: snap.status),
              const SizedBox(height: AegisSpace.xl),
              GestureDetector(
                // Push-to-talk: hold to speak, release to send. Also tappable.
                onTapDown: (_) => ctrl.startPushToTalk(),
                onTapUp: (_) => ctrl.endPushToTalk(),
                onTap: ctrl.toggleListening,
                child: _Orb(status: snap.status, level: snap.soundLevel),
              ),
              const SizedBox(height: AegisSpace.lg),
              _Waveform(level: snap.soundLevel, active: snap.status == VoiceStatus.listening),
              const SizedBox(height: AegisSpace.lg),
              _Transcript(snap: snap),
              const SizedBox(height: AegisSpace.md),
              const _AssistantReply(),
              if (snap.status == VoiceStatus.speaking) ...[
                const SizedBox(height: AegisSpace.sm),
                TextButton.icon(
                  onPressed: ctrl.toggleListening, // barge-in: interrupt & talk
                  icon: const Icon(Icons.pan_tool_alt, size: 16),
                  label: const Text('Tap to interrupt'),
                ),
              ],
              if (snap.status == VoiceStatus.error) ...[
                const SizedBox(height: AegisSpace.lg),
                _ErrorPanel(snap: snap, ctrl: ctrl),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  const _StatusBadge({required this.status});
  final VoiceStatus status;

  ({String label, Color color, IconData icon}) get _cfg => switch (status) {
        VoiceStatus.idle => (label: 'IDLE', color: AegisColors.textMuted, icon: Icons.circle_outlined),
        VoiceStatus.listening => (label: 'LISTENING', color: AegisColors.stateOk, icon: Icons.mic),
        VoiceStatus.processing => (label: 'PROCESSING', color: AegisColors.stateWarn, icon: Icons.auto_awesome),
        VoiceStatus.speaking => (label: 'SPEAKING', color: AegisColors.neonPrimary, icon: Icons.graphic_eq),
        VoiceStatus.error => (label: 'ERROR', color: AegisColors.stateErr, icon: Icons.error_outline),
      };

  @override
  Widget build(BuildContext context) {
    final c = _cfg;
    return AnimatedContainer(
      duration: AegisMotion.base,
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 10),
      decoration: BoxDecoration(
        color: c.color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: c.color.withValues(alpha: 0.4)),
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(c.icon, size: 16, color: c.color),
        const SizedBox(width: 8),
        Text(c.label,
            style: TextStyle(color: c.color, letterSpacing: 2, fontSize: 12, fontWeight: FontWeight.w600)),
      ]),
    );
  }
}

/// Animated AI orb; visual behavior maps to state.
class _Orb extends StatefulWidget {
  const _Orb({required this.status, required this.level});
  final VoiceStatus status;
  final double level;

  @override
  State<_Orb> createState() => _OrbState();
}

class _OrbState extends State<_Orb> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: AegisMotion.pulse)..repeat(reverse: true);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final glow = widget.status == VoiceStatus.listening
        ? 0.4 + widget.level * 0.6
        : 0.5;
    return AnimatedBuilder(
      animation: _c,
      builder: (_, __) {
        final scale = 1 + (_c.value * 0.06) + (widget.status == VoiceStatus.listening ? widget.level * 0.15 : 0);
        return Transform.scale(
          scale: scale,
          child: Container(
            width: 120,
            height: 120,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: const RadialGradient(
                colors: [Color(0xFFBFF3FF), AegisColors.neonPrimary, AegisColors.neonSecondary],
                stops: [0.0, 0.45, 1.0],
              ),
              boxShadow: [
                BoxShadow(color: AegisColors.neonGlow.withValues(alpha: glow), blurRadius: 50, spreadRadius: 6),
              ],
            ),
          ),
        );
      },
    );
  }
}

/// Live waveform painted from real mic amplitude.
class _Waveform extends StatelessWidget {
  const _Waveform({required this.level, required this.active});
  final double level;
  final bool active;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 56,
      width: 240,
      child: CustomPaint(painter: _WavePainter(level: active ? level : 0)),
    );
  }
}

class _WavePainter extends CustomPainter {
  _WavePainter({required this.level});
  final double level;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AegisColors.neonPrimary
      ..strokeCap = StrokeCap.round
      ..strokeWidth = 4;
    const bars = 28;
    final gap = size.width / bars;
    for (var i = 0; i < bars; i++) {
      final t = i / bars;
      // Center-weighted bell so the middle bars react most to speech.
      final bell = 1 - (2 * t - 1).abs();
      final h = (6 + level * 44 * bell).clamp(6, size.height);
      final x = gap * i + gap / 2;
      canvas.drawLine(
        Offset(x, size.height / 2 - h / 2),
        Offset(x, size.height / 2 + h / 2),
        paint..color = AegisColors.neonPrimary.withValues(alpha: 0.35 + bell * 0.65),
      );
    }
  }

  @override
  bool shouldRepaint(covariant _WavePainter old) => old.level != level;
}

class _Transcript extends StatelessWidget {
  const _Transcript({required this.snap});
  final VoiceSnapshot snap;

  @override
  Widget build(BuildContext context) {
    final text = snap.partialTranscript.isNotEmpty
        ? snap.partialTranscript
        : snap.finalTranscript.isNotEmpty
            ? snap.finalTranscript
            : _hint(snap.status);
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: AegisSpace.xl),
      child: Text(text,
          textAlign: TextAlign.center,
          style: TextStyle(
            color: snap.partialTranscript.isNotEmpty ? AegisColors.textPrimary : AegisColors.textMuted,
            fontSize: 16,
          )),
    );
  }

  String _hint(VoiceStatus s) => switch (s) {
        VoiceStatus.idle => 'Tap or hold the orb to speak',
        VoiceStatus.listening => 'Listening…',
        VoiceStatus.processing => 'Thinking…',
        VoiceStatus.speaking => 'Speaking…',
        VoiceStatus.error => '',
      };
}

/// Shows the assistant's streaming reply text under the transcript.
class _AssistantReply extends ConsumerWidget {
  const _AssistantReply();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final delta = ref.watch(assistantVoiceStreamProvider);
    final text = delta.valueOrNull?.fullTextSoFar ?? '';
    if (text.isEmpty) return const SizedBox.shrink();
    return Container(
      constraints: const BoxConstraints(maxWidth: 420),
      margin: const EdgeInsets.symmetric(horizontal: AegisSpace.xl),
      padding: const EdgeInsets.all(AegisSpace.md),
      decoration: BoxDecoration(
        color: AegisColors.glassFill,
        borderRadius: BorderRadius.circular(AegisSpace.radius),
        border: Border.all(color: AegisColors.glassStroke),
      ),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: const TextStyle(color: AegisColors.textPrimary, fontSize: 15, height: 1.5),
      ),
    );
  }
}

class _ErrorPanel extends StatelessWidget {
  const _ErrorPanel({required this.snap, required this.ctrl});
  final VoiceSnapshot snap;
  final VoiceController ctrl;

  @override
  Widget build(BuildContext context) {
    final permanent = snap.blockReason == VoiceBlockReason.permissionPermanentlyDenied;
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: AegisSpace.xl),
      padding: const EdgeInsets.all(AegisSpace.md),
      decoration: BoxDecoration(
        color: AegisColors.stateErr.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(AegisSpace.radius),
        border: Border.all(color: AegisColors.stateErr.withValues(alpha: 0.4)),
      ),
      child: Column(children: [
        Text(snap.errorMessage ?? 'Something went wrong.',
            textAlign: TextAlign.center,
            style: const TextStyle(color: AegisColors.textPrimary)),
        const SizedBox(height: AegisSpace.md),
        FilledButton.icon(
          onPressed: permanent ? ctrl.openSettings : ctrl.retry,
          icon: Icon(permanent ? Icons.settings : Icons.refresh),
          label: Text(permanent ? 'Open Settings' : 'Try again'),
        ),
      ]),
    );
  }
}
