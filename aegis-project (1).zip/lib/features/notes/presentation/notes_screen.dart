// AEGIS — Notes: create, edit, pin, delete. Encrypted at rest.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/di/providers.dart';
import '../../../core/theme/aegis_theme.dart';
import '../../../data/repositories/models.dart';

final _notesProvider = FutureProvider.autoDispose((ref) async {
  return ref.read(notesRepositoryProvider).all();
});

class NotesScreen extends ConsumerWidget {
  const NotesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notes = ref.watch(_notesProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Notes'), backgroundColor: Colors.transparent),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _edit(context, ref, null),
        child: const Icon(Icons.add),
      ),
      body: notes.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(child: Text('$e')),
        data: (items) => items.isEmpty
            ? const _Empty(icon: Icons.notes_rounded, text: 'No notes yet.\nTap + to create one.')
            : ListView.builder(
                padding: const EdgeInsets.all(12),
                itemCount: items.length,
                itemBuilder: (_, i) {
                  final n = items[i];
                  return Card(
                    child: ListTile(
                      leading: Icon(n.pinned ? Icons.push_pin : Icons.note_outlined,
                          color: AegisColors.neonPrimary),
                      title: Text(n.title.isEmpty ? '(untitled)' : n.title,
                          style: const TextStyle(color: AegisColors.textPrimary)),
                      subtitle: Text(n.body,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(color: AegisColors.textMuted)),
                      onTap: () => _edit(context, ref, n),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline, color: AegisColors.textMuted),
                        onPressed: () async {
                          await ref.read(notesRepositoryProvider).delete(n.id);
                          ref.invalidate(_notesProvider);
                        },
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }

  Future<void> _edit(BuildContext context, WidgetRef ref, Note? existing) async {
    final titleCtrl = TextEditingController(text: existing?.title ?? '');
    final bodyCtrl = TextEditingController(text: existing?.body ?? '');
    var pinned = existing?.pinned ?? false;

    final saved = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: AegisColors.bgElevated,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom, left: 16, right: 16, top: 16),
        child: StatefulBuilder(
          builder: (ctx, setSheet) => Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: titleCtrl, decoration: const InputDecoration(labelText: 'Title')),
            const SizedBox(height: 8),
            TextField(controller: bodyCtrl, maxLines: 6, decoration: const InputDecoration(labelText: 'Note')),
            SwitchListTile(
              value: pinned,
              onChanged: (v) => setSheet(() => pinned = v),
              title: const Text('Pin to top', style: TextStyle(color: AegisColors.textPrimary)),
            ),
            const SizedBox(height: 8),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Save')),
            const SizedBox(height: 16),
          ]),
        ),
      ),
    );

    if (saved == true) {
      final repo = ref.read(notesRepositoryProvider);
      if (existing == null) {
        final n = await repo.create(title: titleCtrl.text, body: bodyCtrl.text);
        if (pinned) await repo.update(Note(id: n.id, title: n.title, body: n.body, pinned: true, createdAt: n.createdAt, updatedAt: n.updatedAt));
      } else {
        await repo.update(Note(
            id: existing.id, title: titleCtrl.text, body: bodyCtrl.text, pinned: pinned,
            createdAt: existing.createdAt, updatedAt: DateTime.now()));
      }
      ref.invalidate(_notesProvider);
    }
  }
}

class _Empty extends StatelessWidget {
  const _Empty({required this.icon, required this.text});
  final IconData icon;
  final String text;
  @override
  Widget build(BuildContext context) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(icon, size: 56, color: AegisColors.textMuted),
          const SizedBox(height: 12),
          Text(text, textAlign: TextAlign.center, style: const TextStyle(color: AegisColors.textMuted)),
        ]),
      );
}
