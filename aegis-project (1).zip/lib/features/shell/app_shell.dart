// AEGIS — adaptive app shell.
//
// Tablet-optimized: a glass NavigationRail on wide/landscape screens, a bottom
// NavigationBar on narrow/portrait. Hosts the main destinations. Waits for
// appBootstrap (crypto/db/notifications) before showing content.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/di/providers.dart';
import '../../core/theme/aegis_theme.dart';
import '../chat/presentation/chat_screen.dart';
import '../dashboard/presentation/dashboard_screen.dart';
import '../notes/presentation/notes_screen.dart';
import '../reminders/presentation/reminders_screen.dart';
import '../settings/presentation/ai_settings_screen.dart';
import '../tasks/presentation/tasks_screen.dart';
import '../voice_mode/presentation/voice_mode_screen.dart';

class AppShell extends ConsumerStatefulWidget {
  const AppShell({super.key});
  @override
  ConsumerState<AppShell> createState() => _AppShellState();
}

class _AppShellState extends ConsumerState<AppShell> {
  int _index = 0;

  static const _destinations = [
    (icon: Icons.dashboard_rounded, label: 'Home'),
    (icon: Icons.mic_rounded, label: 'Voice'),
    (icon: Icons.chat_rounded, label: 'Chat'),
    (icon: Icons.check_circle_outline_rounded, label: 'Tasks'),
    (icon: Icons.notes_rounded, label: 'Notes'),
    (icon: Icons.alarm_rounded, label: 'Reminders'),
    (icon: Icons.settings_rounded, label: 'Settings'),
  ];

  Widget _page(int i) => switch (i) {
        0 => DashboardScreen(onNavigate: (n) => setState(() => _index = n)),
        1 => const VoiceModeScreen(),
        2 => const ChatScreen(),
        3 => const TasksScreen(),
        4 => const NotesScreen(),
        5 => const RemindersScreen(),
        _ => const AiSettingsScreen(),
      };

  @override
  Widget build(BuildContext context) {
    final boot = ref.watch(appBootstrapProvider);

    return Scaffold(
      body: boot.when(
        loading: () => const _Splash(),
        error: (e, _) => _Splash(error: '$e'),
        data: (_) => LayoutBuilder(
          builder: (context, constraints) {
            final wide = constraints.maxWidth >= 720; // tablet landscape/large
            if (wide) {
              return Row(children: [
                _GlassRail(
                  index: _index,
                  destinations: _destinations,
                  onSelect: (i) => setState(() => _index = i),
                ),
                Expanded(child: _page(_index)),
              ]);
            }
            return _page(_index);
          },
        ),
      ),
      bottomNavigationBar: boot.hasValue
          ? LayoutBuilder(builder: (context, c) {
              final wide = MediaQuery.of(context).size.width >= 720;
              if (wide) return const SizedBox.shrink();
              return NavigationBar(
                selectedIndex: _index,
                onDestinationSelected: (i) => setState(() => _index = i),
                destinations: _destinations
                    .map((d) => NavigationDestination(icon: Icon(d.icon), label: d.label))
                    .toList(),
              );
            })
          : null,
    );
  }
}

class _GlassRail extends StatelessWidget {
  const _GlassRail({required this.index, required this.destinations, required this.onSelect});
  final int index;
  final List<({IconData icon, String label})> destinations;
  final ValueChanged<int> onSelect;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 96,
      decoration: const BoxDecoration(
        color: AegisColors.glassFill,
        border: Border(right: BorderSide(color: AegisColors.glassStroke)),
      ),
      child: SafeArea(
        child: Column(children: [
          const SizedBox(height: 16),
          const Icon(Icons.hexagon_outlined, color: AegisColors.neonPrimary, size: 34),
          const SizedBox(height: 24),
          Expanded(
            child: ListView(
              children: List.generate(destinations.length, (i) {
                final active = i == index;
                final d = destinations[i];
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 10),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () => onSelect(i),
                    child: Container(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        color: active ? AegisColors.neonPrimary.withValues(alpha: 0.12) : null,
                        borderRadius: BorderRadius.circular(14),
                        border: active ? Border.all(color: AegisColors.glassStroke) : null,
                      ),
                      child: Column(children: [
                        Icon(d.icon, size: 22, color: active ? AegisColors.neonPrimary : AegisColors.textMuted),
                        const SizedBox(height: 4),
                        Text(d.label,
                            style: TextStyle(
                                fontSize: 9,
                                color: active ? AegisColors.neonPrimary : AegisColors.textMuted)),
                      ]),
                    ),
                  ),
                );
              }),
            ),
          ),
        ]),
      ),
    );
  }
}

class _Splash extends StatelessWidget {
  const _Splash({this.error});
  final String? error;
  @override
  Widget build(BuildContext context) {
    return Container(
      color: AegisColors.bgBase,
      child: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.hexagon_outlined, color: AegisColors.neonPrimary, size: 64),
          const SizedBox(height: 16),
          const Text('AEGIS', style: TextStyle(letterSpacing: 8, fontSize: 22, color: AegisColors.textPrimary)),
          const SizedBox(height: 24),
          if (error == null)
            const CircularProgressIndicator(color: AegisColors.neonPrimary)
          else
            Padding(
              padding: const EdgeInsets.all(24),
              child: Text('Startup error:\n$error',
                  textAlign: TextAlign.center, style: const TextStyle(color: AegisColors.stateErr)),
            ),
        ]),
      ),
    );
  }
}
