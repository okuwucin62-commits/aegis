// AEGIS — application entry point.
//
// Boot sequence:
//   1. Ensure Flutter bindings.
//   2. Set preferred orientations / system UI for the dashboard.
//   3. Run the app inside a Riverpod ProviderScope (the DI container).
//
// Engine bootstrapping (DB open, crypto init, settings load) happens lazily via
// Riverpod providers the first time each subsystem is used, so the shell starts
// instantly and nothing blocks first paint.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Immersive dark system bars to match the AEGIS aesthetic.
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF05070D),
    systemNavigationBarIconBrightness: Brightness.light,
  ));

  runApp(const ProviderScope(child: AegisApp()));
}
