// AEGIS — Microphone permission handling.
//
// Wraps permission_handler so the rest of the app deals with a clean, testable
// interface and never has to care about platform quirks. Handles the three
// realistic outcomes: granted, denied-but-askable, permanently-denied.
//
// package: permission_handler: ^11.3.0  (add to pubspec)

import 'package:permission_handler/permission_handler.dart';

enum MicPermissionResult {
  granted,

  /// Denied this time, but we may ask again.
  denied,

  /// User selected "Don't ask again" / permanently blocked -> open Settings.
  permanentlyDenied,

  /// Restricted by device policy (e.g. parental controls / MDM).
  restricted,
}

abstract interface class MicPermissionService {
  Future<bool> isGranted();

  /// Requests the permission if not already granted. Safe to call repeatedly;
  /// it returns immediately if already granted.
  Future<MicPermissionResult> ensureGranted();

  /// Opens the OS app-settings page (used when permanently denied).
  Future<bool> openSettingsPage();
}

class MicPermissionServiceImpl implements MicPermissionService {
  @override
  Future<bool> isGranted() async {
    final status = await Permission.microphone.status;
    return status.isGranted;
  }

  @override
  Future<MicPermissionResult> ensureGranted() async {
    // Fast path: already granted -> no dialog flashes at the user.
    var status = await Permission.microphone.status;
    if (status.isGranted) return MicPermissionResult.granted;
    if (status.isPermanentlyDenied) {
      return MicPermissionResult.permanentlyDenied;
    }
    if (status.isRestricted) return MicPermissionResult.restricted;

    // Trigger the OS permission dialog.
    status = await Permission.microphone.request();

    if (status.isGranted) return MicPermissionResult.granted;
    if (status.isPermanentlyDenied) {
      return MicPermissionResult.permanentlyDenied;
    }
    if (status.isRestricted) return MicPermissionResult.restricted;
    return MicPermissionResult.denied;
  }

  @override
  Future<bool> openSettingsPage() => openAppSettings();
}
