// AEGIS — Design tokens & ThemeData. Mirrors docs/07_DESIGN_SYSTEM.md.
// Dark-first, glassmorphism + electric-cyan neon.

import 'package:flutter/material.dart';

/// Raw color tokens.
abstract final class AegisColors {
  static const bgBase = Color(0xFF05070D);
  static const bgElevated = Color(0xFF0B1020);
  static const glassFill = Color(0x0FFFFFFF); // white @ ~6%
  static const glassStroke = Color(0x2E78C8FF); // cyan @ ~18%
  static const neonPrimary = Color(0xFF22D3FF);
  static const neonSecondary = Color(0xFF3B82F6);
  static const neonGlow = Color(0x7322D3FF); // cyan @ ~45%
  static const textPrimary = Color(0xFFEAF6FF);
  static const textMuted = Color(0xFF8FA3B8);
  static const stateOk = Color(0xFF34D399);
  static const stateWarn = Color(0xFFFBBF24);
  static const stateErr = Color(0xFFF87171);
}

/// Motion tokens.
abstract final class AegisMotion {
  static const fast = Duration(milliseconds: 120);
  static const base = Duration(milliseconds: 240);
  static const slow = Duration(milliseconds: 480);
  static const pulse = Duration(milliseconds: 1600);

  static const curveBase = Curves.easeInOutCubic;
  static const curveFast = Curves.easeOut;
}

/// Spacing / radius scale.
abstract final class AegisSpace {
  static const xs = 4.0;
  static const sm = 8.0;
  static const md = 16.0;
  static const lg = 24.0;
  static const xl = 32.0;
  static const radius = 20.0;
}

abstract final class AegisTheme {
  static ThemeData dark() {
    const scheme = ColorScheme.dark(
      primary: AegisColors.neonPrimary,
      secondary: AegisColors.neonSecondary,
      surface: AegisColors.bgElevated,
      error: AegisColors.stateErr,
      onPrimary: Color(0xFF00151C),
      onSurface: AegisColors.textPrimary,
    );

    final base = ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      colorScheme: scheme,
      scaffoldBackgroundColor: AegisColors.bgBase,
      splashFactory: InkSparkle.splashFactory,
    );

    return base.copyWith(
      textTheme: base.textTheme.apply(
        bodyColor: AegisColors.textPrimary,
        displayColor: AegisColors.textPrimary,
      ),
      cardTheme: const CardTheme(
        color: AegisColors.glassFill,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(AegisSpace.radius)),
          side: BorderSide(color: AegisColors.glassStroke),
        ),
      ),
    );
  }
}
