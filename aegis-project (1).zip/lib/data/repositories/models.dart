// AEGIS — plain data models for persisted entities.

class Note {
  final String id;
  final String title;
  final String body;
  final bool pinned;
  final DateTime createdAt;
  final DateTime updatedAt;
  Note({
    required this.id,
    required this.title,
    required this.body,
    this.pinned = false,
    required this.createdAt,
    required this.updatedAt,
  });
}

enum TaskStatusModel { todo, doing, done }

class TaskItem {
  final String id;
  final String title;
  final String notes;
  final TaskStatusModel status;
  final int priority; // 0 low .. 2 high
  final DateTime? dueAt;
  final DateTime createdAt;
  TaskItem({
    required this.id,
    required this.title,
    this.notes = '',
    this.status = TaskStatusModel.todo,
    this.priority = 1,
    this.dueAt,
    required this.createdAt,
  });

  TaskItem copyWith({String? title, String? notes, TaskStatusModel? status, int? priority, DateTime? dueAt}) =>
      TaskItem(
        id: id,
        title: title ?? this.title,
        notes: notes ?? this.notes,
        status: status ?? this.status,
        priority: priority ?? this.priority,
        dueAt: dueAt ?? this.dueAt,
        createdAt: createdAt,
      );
}

class Reminder {
  final String id;
  final String text;
  final DateTime remindAt;
  final bool done;
  final int notifId;
  final DateTime createdAt;
  Reminder({
    required this.id,
    required this.text,
    required this.remindAt,
    this.done = false,
    required this.notifId,
    required this.createdAt,
  });
}

class ChatMessage {
  final String id;
  final String conversationId;
  final String role; // user | assistant | system
  final String content;
  final DateTime createdAt;
  ChatMessage({
    required this.id,
    required this.conversationId,
    required this.role,
    required this.content,
    required this.createdAt,
  });
}

class Conversation {
  final String id;
  final String title;
  final DateTime createdAt;
  final DateTime updatedAt;
  Conversation({
    required this.id,
    required this.title,
    required this.createdAt,
    required this.updatedAt,
  });
}

/// Small factory so DI can build a ChatMessage without repeating id/time logic.
abstract final class ChatMessageFactory {
  static ChatMessage make(String conversationId, String role, String content) => ChatMessage(
        id: 'msg_${DateTime.now().microsecondsSinceEpoch}',
        conversationId: conversationId,
        role: role,
        content: content,
        createdAt: DateTime.now(),
      );
}
