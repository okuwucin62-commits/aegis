// AEGIS — Chat/conversation repository (encrypted message content).

import '../db/app_database.dart';
import '../../engines/security/crypto_service.dart';
import 'models.dart';

class ChatRepository {
  ChatRepository(this._crypto);
  final CryptoService _crypto;

  int _now() => DateTime.now().millisecondsSinceEpoch;

  Future<Conversation> createConversation(String title) async {
    final db = await AppDatabase.instance.database;
    final now = _now();
    final convo = Conversation(
      id: 'conv_${DateTime.now().microsecondsSinceEpoch}',
      title: title,
      createdAt: DateTime.fromMillisecondsSinceEpoch(now),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(now),
    );
    await db.insert('conversations', {
      'id': convo.id,
      'title': _crypto.encryptString(title),
      'created_at': now,
      'updated_at': now,
    });
    return convo;
  }

  Future<List<Conversation>> conversations() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('conversations', orderBy: 'updated_at DESC');
    return rows
        .map((r) => Conversation(
              id: r['id'] as String,
              title: _crypto.decryptString(r['title'] as String),
              createdAt: DateTime.fromMillisecondsSinceEpoch(r['created_at'] as int),
              updatedAt: DateTime.fromMillisecondsSinceEpoch(r['updated_at'] as int),
            ))
        .toList();
  }

  Future<void> addMessage(ChatMessage m) async {
    final db = await AppDatabase.instance.database;
    await db.insert('messages', {
      'id': m.id,
      'conversation_id': m.conversationId,
      'role': m.role,
      'content': _crypto.encryptString(m.content),
      'created_at': m.createdAt.millisecondsSinceEpoch,
    });
    await db.update('conversations', {'updated_at': _now()},
        where: 'id = ?', whereArgs: [m.conversationId]);
  }

  Future<List<ChatMessage>> messages(String conversationId) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('messages',
        where: 'conversation_id = ?',
        whereArgs: [conversationId],
        orderBy: 'created_at ASC');
    return rows
        .map((r) => ChatMessage(
              id: r['id'] as String,
              conversationId: r['conversation_id'] as String,
              role: r['role'] as String,
              content: _crypto.decryptString(r['content'] as String),
              createdAt: DateTime.fromMillisecondsSinceEpoch(r['created_at'] as int),
            ))
        .toList();
  }

  Future<void> deleteConversation(String id) async {
    final db = await AppDatabase.instance.database;
    await db.delete('conversations', where: 'id = ?', whereArgs: [id]);
  }
}
