// AEGIS — Reminders repository (encrypted text) + notification scheduling hook.

import '../db/app_database.dart';
import '../../engines/security/crypto_service.dart';
import '../../engines/notifications/notification_service.dart';
import 'models.dart';

class RemindersRepository {
  RemindersRepository(this._crypto, this._notifications);
  final CryptoService _crypto;
  final NotificationService _notifications;

  int _now() => DateTime.now().millisecondsSinceEpoch;
  String _id() => 'rem_${DateTime.now().microsecondsSinceEpoch}';

  Future<List<Reminder>> all() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('reminders', orderBy: 'done ASC, remind_at ASC');
    return rows.map(_fromRow).toList();
  }

  Future<Reminder> create({required String text, required DateTime remindAt}) async {
    final db = await AppDatabase.instance.database;
    final now = _now();
    final notifId = now ~/ 1000 & 0x7fffffff; // stable 32-bit id
    final reminder = Reminder(
      id: _id(),
      text: text,
      remindAt: remindAt,
      notifId: notifId,
      createdAt: DateTime.fromMillisecondsSinceEpoch(now),
    );
    await db.insert('reminders', {
      'id': reminder.id,
      'text': _crypto.encryptString(text),
      'remind_at': remindAt.millisecondsSinceEpoch,
      'done': 0,
      'notif_id': notifId,
      'created_at': now,
    });
    await _notifications.schedule(
      id: notifId,
      title: 'AEGIS Reminder',
      body: text,
      when: remindAt,
    );
    return reminder;
  }

  Future<void> markDone(Reminder r) async {
    final db = await AppDatabase.instance.database;
    await db.update('reminders', {'done': 1}, where: 'id = ?', whereArgs: [r.id]);
    await _notifications.cancel(r.notifId);
  }

  Future<void> delete(Reminder r) async {
    final db = await AppDatabase.instance.database;
    await db.delete('reminders', where: 'id = ?', whereArgs: [r.id]);
    await _notifications.cancel(r.notifId);
  }

  Reminder _fromRow(Map<String, Object?> r) => Reminder(
        id: r['id'] as String,
        text: _crypto.decryptString(r['text'] as String),
        remindAt: DateTime.fromMillisecondsSinceEpoch(r['remind_at'] as int),
        done: (r['done'] as int) == 1,
        notifId: r['notif_id'] as int,
        createdAt: DateTime.fromMillisecondsSinceEpoch(r['created_at'] as int),
      );
}
