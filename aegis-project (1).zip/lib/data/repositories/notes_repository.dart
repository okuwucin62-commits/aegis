// AEGIS — Notes repository (encrypted body at rest).

import '../db/app_database.dart';
import '../../engines/security/crypto_service.dart';
import 'models.dart';

class NotesRepository {
  NotesRepository(this._crypto);
  final CryptoService _crypto;

  int _now() => DateTime.now().millisecondsSinceEpoch;
  String _id() => 'note_${DateTime.now().microsecondsSinceEpoch}';

  Future<List<Note>> all() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('notes', orderBy: 'pinned DESC, updated_at DESC');
    return rows.map(_fromRow).toList();
  }

  Future<Note> create({required String title, required String body}) async {
    final db = await AppDatabase.instance.database;
    final now = _now();
    final note = Note(
      id: _id(),
      title: title,
      body: body,
      createdAt: DateTime.fromMillisecondsSinceEpoch(now),
      updatedAt: DateTime.fromMillisecondsSinceEpoch(now),
    );
    await db.insert('notes', {
      'id': note.id,
      'title': _crypto.encryptString(title),
      'body': _crypto.encryptString(body),
      'pinned': 0,
      'created_at': now,
      'updated_at': now,
    });
    return note;
  }

  Future<void> update(Note note) async {
    final db = await AppDatabase.instance.database;
    await db.update(
      'notes',
      {
        'title': _crypto.encryptString(note.title),
        'body': _crypto.encryptString(note.body),
        'pinned': note.pinned ? 1 : 0,
        'updated_at': _now(),
      },
      where: 'id = ?',
      whereArgs: [note.id],
    );
  }

  Future<void> delete(String id) async {
    final db = await AppDatabase.instance.database;
    await db.delete('notes', where: 'id = ?', whereArgs: [id]);
  }

  Note _fromRow(Map<String, Object?> r) => Note(
        id: r['id'] as String,
        title: _crypto.decryptString(r['title'] as String),
        body: _crypto.decryptString(r['body'] as String),
        pinned: (r['pinned'] as int) == 1,
        createdAt: DateTime.fromMillisecondsSinceEpoch(r['created_at'] as int),
        updatedAt: DateTime.fromMillisecondsSinceEpoch(r['updated_at'] as int),
      );
}
