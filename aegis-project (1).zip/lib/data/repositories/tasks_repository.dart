// AEGIS — Tasks repository (encrypted title/notes at rest).

import '../db/app_database.dart';
import '../../engines/security/crypto_service.dart';
import 'models.dart';

class TasksRepository {
  TasksRepository(this._crypto);
  final CryptoService _crypto;

  int _now() => DateTime.now().millisecondsSinceEpoch;
  String _id() => 'task_${DateTime.now().microsecondsSinceEpoch}';

  Future<List<TaskItem>> all() async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('tasks', orderBy: 'status ASC, priority DESC, created_at DESC');
    return rows.map(_fromRow).toList();
  }

  Future<TaskItem> create({required String title, int priority = 1, DateTime? dueAt}) async {
    final db = await AppDatabase.instance.database;
    final now = _now();
    final task = TaskItem(
      id: _id(),
      title: title,
      priority: priority,
      dueAt: dueAt,
      createdAt: DateTime.fromMillisecondsSinceEpoch(now),
    );
    await db.insert('tasks', _toRow(task));
    return task;
  }

  Future<void> update(TaskItem task) async {
    final db = await AppDatabase.instance.database;
    await db.update('tasks', _toRow(task), where: 'id = ?', whereArgs: [task.id]);
  }

  Future<void> delete(String id) async {
    final db = await AppDatabase.instance.database;
    await db.delete('tasks', where: 'id = ?', whereArgs: [id]);
  }

  Map<String, Object?> _toRow(TaskItem t) => {
        'id': t.id,
        'title': _crypto.encryptString(t.title),
        'notes': _crypto.encryptString(t.notes),
        'status': t.status.name,
        'priority': t.priority,
        'due_at': t.dueAt?.millisecondsSinceEpoch,
        'created_at': t.createdAt.millisecondsSinceEpoch,
      };

  TaskItem _fromRow(Map<String, Object?> r) => TaskItem(
        id: r['id'] as String,
        title: _crypto.decryptString(r['title'] as String),
        notes: _crypto.decryptString(r['notes'] as String),
        status: TaskStatusModel.values.firstWhere(
          (s) => s.name == r['status'],
          orElse: () => TaskStatusModel.todo,
        ),
        priority: r['priority'] as int,
        dueAt: r['due_at'] == null
            ? null
            : DateTime.fromMillisecondsSinceEpoch(r['due_at'] as int),
        createdAt: DateTime.fromMillisecondsSinceEpoch(r['created_at'] as int),
      );
}
