// AEGIS — Settings repository. Small key/value store in SQLite.
// API keys are encrypted; plain preferences are stored as-is.

import 'package:sqflite/sqflite.dart';

import '../db/app_database.dart';
import '../../engines/security/crypto_service.dart';

class SettingsRepository {
  SettingsRepository(this._crypto);
  final CryptoService _crypto;

  static const _secretKeys = {'openai_api_key'};

  Future<String?> get(String key) async {
    final db = await AppDatabase.instance.database;
    final rows = await db.query('settings', where: 'key = ?', whereArgs: [key], limit: 1);
    if (rows.isEmpty) return null;
    final raw = rows.first['value'] as String;
    return _secretKeys.contains(key) ? _crypto.decryptString(raw) : raw;
  }

  Future<void> set(String key, String value) async {
    final db = await AppDatabase.instance.database;
    final stored = _secretKeys.contains(key) ? _crypto.encryptString(value) : value;
    await db.insert(
      'settings',
      {'key': key, 'value': stored},
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<bool> has(String key) async => (await get(key))?.isNotEmpty ?? false;
}
