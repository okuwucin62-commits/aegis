// AEGIS — Conversation Orchestrator (streaming voice + text, memory-backed).
//
// Turns discrete parts (voice, AI, memory) into a flowing conversation:
//   voice/text in -> memory context -> streaming AI -> sentence-level TTS.
// Supports barge-in interruption (tap or voice). Persists every turn via the
// injected onPersist callback so conversation history survives restarts.

import 'dart:async';

import '../ai/ai_provider.dart';
import '../memory/memory_service.dart';
import '../voice/voice_engine.dart';
import '../voice/voice_state.dart';
import '../../domain/entities/conversation.dart';

class AssistantDelta {
  final String turnId;
  final String fullTextSoFar;
  final bool isFinal;
  const AssistantDelta({
    required this.turnId,
    required this.fullTextSoFar,
    required this.isFinal,
  });
}

/// Persistence hook: (role, content) -> store in DB. Fire-and-forget.
typedef PersistTurn = void Function(String role, String content);

class ConversationOrchestrator {
  ConversationOrchestrator({
    required VoiceEngine voice,
    required AiProvider provider,
    required MemoryService memory,
    required String modelId,
    this.onPersist,
    this.speakReplies = true,
  })  : _voice = voice,
        _provider = provider,
        _memory = memory,
        _modelId = modelId {
    _voice.onUtterance = handleUserInput;
    _voice.onBargeIn = stopSpeaking;
  }

  final VoiceEngine _voice;
  final AiProvider _provider;
  final MemoryService _memory;
  final String _modelId;
  final PersistTurn? onPersist;
  bool speakReplies;

  final _deltas = StreamController<AssistantDelta>.broadcast();
  Stream<AssistantDelta> get assistantStream => _deltas.stream;

  StreamSubscription<AiStreamChunk>? _aiSub;
  bool _responding = false;
  int _turnCounter = 0;

  bool get isResponding => _responding;

  Future<void> onUserWantsToSpeak() async {
    if (_responding) await _interrupt();
    await _voice.startListening();
  }

  Future<void> stopSpeaking() => _interrupt();

  Future<void> _interrupt() async {
    await _aiSub?.cancel();
    _aiSub = null;
    await _voice.stopSpeaking();
    _responding = false;
  }

  /// Entry point for both voice (via onUtterance) and typed text.
  Future<void> handleUserInput(String text) async {
    final trimmed = text.trim();
    if (trimmed.isEmpty) return;
    if (_responding) await _interrupt();

    _memory.addTurn(Turn(
      id: 'u${_turnCounter++}',
      role: AiRole.user,
      content: trimmed,
      at: DateTime.now(),
    ));
    onPersist?.call('user', trimmed);
    unawaited(_memory.maybeExtractLongTerm(trimmed));

    _responding = true;
    final turnId = 'a${_turnCounter++}';
    final spoken = _SentenceSpeaker(_voice, enabled: speakReplies);
    final full = StringBuffer();

    List<AiMessage> context;
    try {
      context = await _memory.buildContext(trimmed);
    } catch (e) {
      _responding = false;
      _emitError('I had trouble accessing memory.');
      return;
    }

    try {
      final completer = Completer<void>();
      _aiSub = _provider.stream(context, modelId: _modelId).listen(
        (chunk) async {
          if (chunk.deltaText.isNotEmpty) {
            full.write(chunk.deltaText);
            _deltas.add(AssistantDelta(
                turnId: turnId, fullTextSoFar: full.toString(), isFinal: false));
            await spoken.feed(chunk.deltaText);
          }
          if (chunk.isDone && !completer.isCompleted) completer.complete();
        },
        onError: (Object e) {
          if (!completer.isCompleted) completer.completeError(e);
        },
        onDone: () {
          if (!completer.isCompleted) completer.complete();
        },
        cancelOnError: true,
      );
      await completer.future;
      await spoken.flush();
    } catch (e) {
      _emitError(_friendly(e));
    } finally {
      await _aiSub?.cancel();
      _aiSub = null;
    }

    final finalText = full.toString().trim();
    if (finalText.isNotEmpty) {
      _memory.addTurn(Turn(
        id: turnId,
        role: AiRole.assistant,
        content: finalText,
        at: DateTime.now(),
      ));
      onPersist?.call('assistant', finalText);
      _deltas.add(AssistantDelta(turnId: turnId, fullTextSoFar: finalText, isFinal: true));
    }
    _responding = false;
  }

  void _emitError(String message) {
    _deltas.add(AssistantDelta(turnId: 'err', fullTextSoFar: message, isFinal: true));
    if (speakReplies) _voice.speak(message);
  }

  String _friendly(Object e) {
    if (e is AiAuthFailure) return 'My AI key seems invalid. Please check Settings.';
    if (e is AiRateLimitFailure) return 'I am being rate limited. One moment.';
    if (e is AiNetworkFailure) return 'I cannot reach the network right now.';
    return 'Sorry, I ran into a problem answering that.';
  }

  Future<void> dispose() async {
    await _aiSub?.cancel();
    await _deltas.close();
  }
}

/// Speaks completed sentences as they stream (low latency).
class _SentenceSpeaker {
  _SentenceSpeaker(this._voice, {required this.enabled});
  final VoiceEngine _voice;
  final bool enabled;
  final StringBuffer _buf = StringBuffer();
  Future<void> _queue = Future.value();
  static final _boundary = RegExp(r'[.!?…]["\)\]]?\s');

  Future<void> feed(String delta) async {
    if (!enabled) return;
    _buf.write(delta);
    var text = _buf.toString();
    while (true) {
      final match = _boundary.firstMatch(text);
      if (match == null) break;
      final end = match.end;
      final sentence = text.substring(0, end).trim();
      text = text.substring(end);
      if (sentence.isNotEmpty) _enqueue(sentence);
    }
    _buf..clear()..write(text);
  }

  Future<void> flush() async {
    if (!enabled) return;
    final rest = _buf.toString().trim();
    if (rest.isNotEmpty) _enqueue(rest);
    _buf.clear();
    await _queue;
  }

  void _enqueue(String sentence) {
    _queue = _queue.then((_) => _voice.speak(sentence));
  }
}
