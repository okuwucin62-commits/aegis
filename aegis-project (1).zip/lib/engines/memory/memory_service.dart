// AEGIS — Memory System.
//
// Two tiers, both feeding the prompt that goes to the AI:
//   * SHORT-TERM: a rolling buffer of the current conversation's turns. When it
//     grows past a token budget, the oldest turns are compressed into a running
//     summary (so context is preserved without unbounded prompt growth).
//   * LONG-TERM: durable facts/preferences/events retrieved by hybrid search
//     (vector similarity + keyword + recency). Interface here; the vector store
//     impl is wired in a later step (pluggable, injected).
//
// The orchestrator calls [buildContext] before each AI turn to assemble the
// full message list: system prompt + long-term recall + running summary +
// recent turns + the new user message.

import '../../domain/entities/conversation.dart';
import '../ai/ai_provider.dart';

/// Rough token estimate (chars/4). Good enough for budgeting; exact counting
/// would need a tokenizer per model, which we can add later.
int _estimateTokens(String s) => (s.length / 4).ceil();

abstract interface class LongTermMemory {
  /// Retrieve the most relevant memories for [query].
  Future<List<MemoryHit>> recall(String query, {int limit = 5});

  /// Persist a new memory item (fact/preference/event/summary).
  Future<void> remember(String content, {required MemoryKind kind, double importance});
}

/// No-op long-term store so the conversation loop runs before the vector DB is
/// wired. It simply returns nothing and swallows writes.
class NoopLongTermMemory implements LongTermMemory {
  @override
  Future<List<MemoryHit>> recall(String query, {int limit = 5}) async => const [];

  @override
  Future<void> remember(String content, {required MemoryKind kind, double importance = 0.5}) async {}
}

class MemoryService {
  MemoryService({
    required AiProvider provider,
    required String modelId,
    LongTermMemory? longTerm,
    this.tokenBudget = 3000,
    this.summaryTriggerTokens = 2400,
    String? systemPrompt,
  })  : _provider = provider,
        _modelId = modelId,
        _longTerm = longTerm ?? NoopLongTermMemory(),
        _systemPrompt = systemPrompt ?? _defaultSystemPrompt;

  final AiProvider _provider;
  final String _modelId;
  final LongTermMemory _longTerm;
  final int tokenBudget;
  final int summaryTriggerTokens;
  final String _systemPrompt;

  /// Ordered recent turns (short-term memory).
  final List<Turn> _recent = [];

  /// Running compressed summary of older, evicted turns.
  String _runningSummary = '';

  List<Turn> get recentTurns => List.unmodifiable(_recent);
  String get runningSummary => _runningSummary;

  static const _defaultSystemPrompt = '''
You are AEGIS, a calm, precise, proactive personal AI operating assistant.
You are speaking with the user by voice, so:
- Keep replies conversational and concise; avoid long lists unless asked.
- Use natural spoken phrasing (this text will be read aloud by TTS).
- Be accurate; if unsure, say so briefly.
- Remember and use relevant context about the user.''';

  void addTurn(Turn turn) => _recent.add(turn);

  void clear() {
    _recent.clear();
    _runningSummary = '';
  }

  /// Assemble the full prompt for the next AI turn, given the new user text.
  /// Order: system → long-term recall → running summary → recent turns.
  Future<List<AiMessage>> buildContext(String userText) async {
    await _maybeSummarize();

    final messages = <AiMessage>[
      AiMessage(role: AiRole.system, content: _systemPrompt),
    ];

    // Long-term recall injected as system context.
    final hits = await _longTerm.recall(userText, limit: 5);
    if (hits.isNotEmpty) {
      final recallText = hits.map((h) => '- ${h.content}').join('\n');
      messages.add(AiMessage(
        role: AiRole.system,
        content: 'Relevant things you remember about the user:\n$recallText',
      ));
    }

    if (_runningSummary.isNotEmpty) {
      messages.add(AiMessage(
        role: AiRole.system,
        content: 'Summary of earlier conversation:\n$_runningSummary',
      ));
    }

    messages.addAll(_recent.map((t) => t.toAiMessage()));
    return messages;
  }

  int get _recentTokens =>
      _recent.fold(0, (sum, t) => sum + _estimateTokens(t.content));

  /// When the buffer exceeds the trigger, compress the oldest half into the
  /// running summary and drop those turns from the active buffer.
  Future<void> _maybeSummarize() async {
    if (_recentTokens < summaryTriggerTokens || _recent.length < 6) return;

    final half = _recent.length ~/ 2;
    final toSummarize = _recent.take(half).toList();
    final transcript = toSummarize
        .map((t) => '${t.role == AiRole.user ? 'User' : 'AEGIS'}: ${t.content}')
        .join('\n');

    try {
      final result = await _provider.chat(
        [
          const AiMessage(
            role: AiRole.system,
            content:
                'Summarize the following conversation concisely, preserving '
                'facts, decisions, names, and the user\'s goals. Third person.',
          ),
          AiMessage(role: AiRole.user, content: transcript),
        ],
        modelId: _modelId,
        options: const AiChatOptions(temperature: 0.3, maxTokens: 220),
      );
      _runningSummary = _runningSummary.isEmpty
          ? result.content
          : '$_runningSummary\n${result.content}';
      _recent.removeRange(0, half);
    } catch (_) {
      // If summarization fails, fall back to a hard trim so we never overflow.
      if (_recent.length > 8) _recent.removeRange(0, _recent.length - 8);
    }
  }

  /// Extract a durable memory from a completed exchange (fire-and-forget).
  Future<void> maybeExtractLongTerm(String userText) async {
    // Lightweight heuristic hook; a smarter extractor can replace this.
    final lower = userText.toLowerCase();
    if (lower.contains('remember') ||
        lower.contains('my name is') ||
        lower.contains('i prefer') ||
        lower.contains('i like')) {
      await _longTerm.remember(userText,
          kind: MemoryKind.preference, importance: 0.8);
    }
  }
}
