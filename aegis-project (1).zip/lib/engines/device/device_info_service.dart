// AEGIS — device information (Android-permitted, no special permission needed).

import 'package:device_info_plus/device_info_plus.dart';
import 'package:package_info_plus/package_info_plus.dart';

abstract final class DeviceInfoService {
  static Future<String> summary() async {
    try {
      final pkg = await PackageInfo.fromPlatform();
      final info = DeviceInfoPlugin();
      final android = await info.androidInfo;
      return '${android.manufacturer} ${android.model} · Android ${android.version.release} '
          '(SDK ${android.version.sdkInt})\nAEGIS v${pkg.version}+${pkg.buildNumber}';
    } catch (e) {
      return 'Device info unavailable ($e)';
    }
  }
}
