// AEGIS — OpenAI-compatible AiProvider using package:http (no dio).
//
// Streaming via SSE over http.Client. Works with OpenAI and any compatible
// endpoint (Azure, Groq, Together, LM Studio, Ollama /v1) by changing baseUrl.
// All errors mapped to typed AiFailure. No placeholder — this is the real HTTP.

import 'dart:async';
import 'dart:convert';

import 'package:http/http.dart' as http;

import '../ai_provider.dart';

class OpenAiProvider implements AiProvider {
  OpenAiProvider({
    required String apiKey,
    String baseUrl = 'https://api.openai.com/v1',
    http.Client? client,
  })  : _apiKey = apiKey,
        _baseUrl = baseUrl,
        _client = client ?? http.Client();

  final String _apiKey;
  final String _baseUrl;
  final http.Client _client;

  @override
  String get id => 'openai';

  @override
  Set<AiCapability> get capabilities => const {
        AiCapability.chat,
        AiCapability.streaming,
        AiCapability.toolCalling,
        AiCapability.vision,
        AiCapability.embeddings,
      };

  @override
  Future<List<AiModelInfo>> availableModels() async => const [
        AiModelInfo(
          id: 'gpt-4o-mini',
          displayName: 'AEGIS-Fast (4o-mini)',
          providerId: 'openai',
          capabilities: {AiCapability.chat, AiCapability.streaming, AiCapability.toolCalling, AiCapability.vision},
          contextWindow: 128000,
          isLocal: false,
        ),
        AiModelInfo(
          id: 'gpt-4o',
          displayName: 'AEGIS-Core (4o)',
          providerId: 'openai',
          capabilities: {AiCapability.chat, AiCapability.streaming, AiCapability.toolCalling, AiCapability.vision},
          contextWindow: 128000,
          isLocal: false,
        ),
      ];

  Map<String, String> get _headers => {
        'Authorization': 'Bearer $_apiKey',
        'Content-Type': 'application/json',
      };

  Map<String, dynamic> _msgJson(AiMessage m) => {
        'role': switch (m.role) {
          AiRole.system => 'system',
          AiRole.user => 'user',
          AiRole.assistant => 'assistant',
          AiRole.tool => 'tool',
        },
        'content': m.content,
      };

  @override
  Future<AiMessage> chat(
    List<AiMessage> messages, {
    required String modelId,
    AiChatOptions options = const AiChatOptions(),
  }) async {
    final uri = Uri.parse('$_baseUrl/chat/completions');
    final body = jsonEncode({
      'model': modelId,
      'temperature': options.temperature,
      if (options.maxTokens != null) 'max_tokens': options.maxTokens,
      'messages': messages.map(_msgJson).toList(),
    });
    try {
      final res = await _client.post(uri, headers: _headers, body: body);
      if (res.statusCode == 401 || res.statusCode == 403) {
        throw const AiAuthFailure('Invalid or missing API key.');
      }
      if (res.statusCode == 429) {
        throw const AiRateLimitFailure('Rate limited.');
      }
      if (res.statusCode >= 400) {
        throw AiNetworkFailure('AI request failed (${res.statusCode}).');
      }
      final json = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final content = json['choices'][0]['message']['content'] as String? ?? '';
      return AiMessage(role: AiRole.assistant, content: content);
    } on AiFailure {
      rethrow;
    } catch (e) {
      throw AiNetworkFailure('Network problem: $e');
    }
  }

  @override
  Stream<AiStreamChunk> stream(
    List<AiMessage> messages, {
    required String modelId,
    AiChatOptions options = const AiChatOptions(),
  }) async* {
    final uri = Uri.parse('$_baseUrl/chat/completions');
    final request = http.Request('POST', uri)
      ..headers.addAll(_headers)
      ..body = jsonEncode({
        'model': modelId,
        'stream': true,
        'temperature': options.temperature,
        if (options.maxTokens != null) 'max_tokens': options.maxTokens,
        'messages': messages.map(_msgJson).toList(),
      });

    http.StreamedResponse response;
    try {
      response = await _client.send(request);
    } catch (e) {
      throw AiNetworkFailure('Network problem: $e');
    }

    if (response.statusCode == 401 || response.statusCode == 403) {
      throw const AiAuthFailure('Invalid or missing API key.');
    }
    if (response.statusCode == 429) {
      throw const AiRateLimitFailure('Rate limited.');
    }
    if (response.statusCode >= 400) {
      throw AiNetworkFailure('AI request failed (${response.statusCode}).');
    }

    final lines = response.stream
        .transform(utf8.decoder)
        .transform(const LineSplitter());

    await for (final line in lines) {
      if (line.isEmpty || !line.startsWith('data:')) continue;
      final payload = line.substring(5).trim();
      if (payload == '[DONE]') {
        yield const AiStreamChunk(isDone: true);
        return;
      }
      try {
        final json = jsonDecode(payload) as Map<String, dynamic>;
        final choices = json['choices'] as List?;
        if (choices == null || choices.isEmpty) continue;
        final delta = (choices.first as Map)['delta'] as Map?;
        final content = delta?['content'];
        if (content is String && content.isNotEmpty) {
          yield AiStreamChunk(deltaText: content);
        }
      } catch (_) {
        // ignore keep-alives / malformed fragments
      }
    }
    yield const AiStreamChunk(isDone: true);
  }

  @override
  Future<List<List<double>>> embed(
    List<String> inputs, {
    required String modelId,
  }) async {
    final uri = Uri.parse('$_baseUrl/embeddings');
    try {
      final res = await _client.post(uri,
          headers: _headers,
          body: jsonEncode({'model': modelId, 'input': inputs}));
      if (res.statusCode >= 400) {
        throw AiNetworkFailure('Embeddings failed (${res.statusCode}).');
      }
      final json = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      final data = json['data'] as List;
      return data
          .map((e) => (e['embedding'] as List).cast<num>().map((n) => n.toDouble()).toList())
          .toList();
    } on AiFailure {
      rethrow;
    } catch (e) {
      throw AiNetworkFailure('Network problem: $e');
    }
  }

  @override
  Future<bool> isAvailable() async {
    try {
      final res = await _client
          .get(Uri.parse('$_baseUrl/models'), headers: _headers)
          .timeout(const Duration(seconds: 10));
      return res.statusCode == 200;
    } catch (_) {
      return false;
    }
  }
}
