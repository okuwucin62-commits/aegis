// AEGIS — AI Engine: provider-agnostic interface.
//
// This is the seam that makes "switch between models" and "local + cloud AI"
// possible without touching UI or domain code. Every provider (OpenAI,
// Anthropic, Gemini, on-device llama.cpp) implements this contract; the
// [ModelRouter] selects one at runtime by capability, availability and the
// user's preference.
//
// Design principles:
//  - Pure Dart, no UI/framework imports (belongs to the engine layer).
//  - Streaming-first: assistants feel alive when tokens stream.
//  - Tool/function calling is first-class (skills, plugins, research).
//  - Errors are typed, never thrown as opaque exceptions to the UI.

import 'dart:async';

/// A single message in a conversation, provider-neutral.
class AiMessage {
  final AiRole role;
  final String content;

  /// Optional structured tool call the model wants the host to execute.
  final AiToolCall? toolCall;

  /// Optional result being fed back to the model after a tool ran.
  final String? toolResult;

  const AiMessage({
    required this.role,
    required this.content,
    this.toolCall,
    this.toolResult,
  });
}

enum AiRole { system, user, assistant, tool }

/// A declared capability, used by the router to pick a provider for a task.
enum AiCapability {
  chat,
  streaming,
  toolCalling,
  vision, // image understanding
  imageGeneration,
  embeddings,
  offline, // runs with no network
}

/// A tool the model may call (function-calling schema, JSON-schema params).
class AiToolSpec {
  final String name;
  final String description;

  /// JSON Schema describing the tool's parameters.
  final Map<String, dynamic> parametersSchema;

  const AiToolSpec({
    required this.name,
    required this.description,
    required this.parametersSchema,
  });
}

/// A concrete tool invocation emitted by the model.
class AiToolCall {
  final String id;
  final String name;
  final Map<String, dynamic> arguments;

  const AiToolCall({
    required this.id,
    required this.name,
    required this.arguments,
  });
}

/// Options for a single completion request.
class AiChatOptions {
  final double temperature;
  final int? maxTokens;
  final List<AiToolSpec> tools;

  /// Provider-specific overrides (kept opaque to the core).
  final Map<String, dynamic> extra;

  const AiChatOptions({
    this.temperature = 0.7,
    this.maxTokens,
    this.tools = const [],
    this.extra = const {},
  });
}

/// Incremental chunk from a streaming response.
class AiStreamChunk {
  final String deltaText;
  final AiToolCall? toolCall;
  final bool isDone;

  const AiStreamChunk({
    this.deltaText = '',
    this.toolCall,
    this.isDone = false,
  });
}

/// Typed failure surface — the UI/domain map these to friendly messages.
sealed class AiFailure implements Exception {
  final String message;
  const AiFailure(this.message);
}

class AiNetworkFailure extends AiFailure {
  const AiNetworkFailure(super.message);
}

class AiAuthFailure extends AiFailure {
  const AiAuthFailure(super.message);
}

class AiRateLimitFailure extends AiFailure {
  final Duration? retryAfter;
  const AiRateLimitFailure(super.message, {this.retryAfter});
}

class AiUnsupportedFailure extends AiFailure {
  const AiUnsupportedFailure(super.message);
}

/// Metadata describing a selectable model.
class AiModelInfo {
  final String id; // e.g. "gpt-4o", "claude-3-5-sonnet", "gemma-2b-local"
  final String displayName;
  final String providerId;
  final Set<AiCapability> capabilities;
  final int contextWindow;
  final bool isLocal;

  const AiModelInfo({
    required this.id,
    required this.displayName,
    required this.providerId,
    required this.capabilities,
    required this.contextWindow,
    required this.isLocal,
  });
}

/// The core contract every AI backend implements.
abstract interface class AiProvider {
  /// Stable id, e.g. "openai", "anthropic", "gemini", "local".
  String get id;

  /// Models this provider currently exposes.
  Future<List<AiModelInfo>> availableModels();

  /// Capabilities this provider supports right now (may depend on connectivity).
  Set<AiCapability> get capabilities;

  /// One-shot completion. Throws an [AiFailure] subtype on error.
  Future<AiMessage> chat(
    List<AiMessage> messages, {
    required String modelId,
    AiChatOptions options = const AiChatOptions(),
  });

  /// Streaming completion. Emits chunks; closes when [isDone] is true.
  Stream<AiStreamChunk> stream(
    List<AiMessage> messages, {
    required String modelId,
    AiChatOptions options = const AiChatOptions(),
  });

  /// Embeddings for semantic memory. Returns one vector per input.
  Future<List<List<double>>> embed(
    List<String> inputs, {
    required String modelId,
  });

  /// Cheap health probe used by the router for availability checks.
  Future<bool> isAvailable();
}
