// AEGIS — Notification service.
//
// IMPORTANT DESIGN NOTE: we deliberately AVOID `zonedSchedule`, whose required
// parameters changed between plugin major versions (v17 required
// `uiLocalNotificationDateInterpretation`; v18+ removed it). To be immune to
// version drift on cloud CI, we schedule with an in-app Dart timer that fires
// `show()` at the target time. `show()` has a stable signature across all
// versions. For reminders while the app is alive/backgrounded this is reliable;
// exact background-after-kill delivery can be upgraded later without touching
// callers.

import 'dart:async';

import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  final FlutterLocalNotificationsPlugin _plugin =
      FlutterLocalNotificationsPlugin();
  bool _initialized = false;

  // Active in-app timers keyed by notification id, so we can cancel them.
  final Map<int, Timer> _timers = {};

  Future<void> initialize() async {
    if (_initialized) return;

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await _plugin.initialize(settings);

    // Request runtime notification permission on Android 13+ (best-effort).
    try {
      final androidImpl = _plugin.resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>();
      await androidImpl?.requestNotificationsPermission();
    } catch (_) {
      // Older/newer plugin may name this differently; ignore if unavailable.
    }

    _initialized = true;
  }

  NotificationDetails get _details => const NotificationDetails(
        android: AndroidNotificationDetails(
          'aegis_reminders',
          'AEGIS Reminders',
          channelDescription: 'Scheduled reminders from AEGIS',
          importance: Importance.high,
          priority: Priority.high,
        ),
      );

  /// Schedule a reminder. Uses a Dart timer that fires show() at [when].
  Future<void> schedule({
    required int id,
    required String title,
    required String body,
    required DateTime when,
  }) async {
    if (!_initialized) await initialize();

    final delay = when.difference(DateTime.now());
    // If it's already due (or within 2s), show immediately.
    if (delay.inMilliseconds <= 2000) {
      await _plugin.show(id, title, body, _details);
      return;
    }
    _timers[id]?.cancel();
    _timers[id] = Timer(delay, () async {
      try {
        await _plugin.show(id, title, body, _details);
      } catch (_) {}
      _timers.remove(id);
    });
  }

  Future<void> showNow(String title, String body) async {
    if (!_initialized) await initialize();
    await _plugin.show(
      DateTime.now().millisecondsSinceEpoch.remainder(100000),
      title,
      body,
      const NotificationDetails(
        android: AndroidNotificationDetails('aegis_general', 'AEGIS'),
      ),
    );
  }

  Future<void> cancel(int id) async {
    _timers.remove(id)?.cancel();
    if (_initialized) {
      try {
        await _plugin.cancel(id);
      } catch (_) {}
    }
  }
}
