// AEGIS — Voice Engine (production implementation).
//
// Responsibilities:
//   * Own the microphone permission flow (auto-request when needed).
//   * Initialize and drive on-device speech recognition (STT).
//   * Drive text-to-speech (TTS) playback.
//   * Expose a single reactive [VoiceSnapshot] stream that the UI renders.
//   * Recover gracefully from EVERY documented failure mode.
//
// Packages (add to pubspec.yaml):
//   speech_to_text: ^7.0.0      # on-device STT (uses Android SpeechRecognizer)
//   flutter_tts: ^4.2.0         # on-device TTS
//   permission_handler: ^11.3.0
//
// Design rationale:
//   speech_to_text uses Android's native SpeechRecognizer, which is the most
//   reliable, lowest-latency path on Android tablets/phones (it runs in the
//   system, supports offline on many devices, and doesn't need our own audio
//   pipeline). We add aggressive timeouts + auto-restart because the native
//   recognizer stops itself after a pause; a hands-free assistant must
//   re-arm automatically.

import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';

import '../../core/permissions/mic_permission_service.dart';
import 'voice_state.dart';

/// Callback the engine fires when a final utterance is ready for the AI.
typedef OnUtterance = void Function(String transcript);

class VoiceEngine {
  VoiceEngine({
    required MicPermissionService permissions,
    stt.SpeechToText? speech,
    FlutterTts? tts,
  })  : _permissions = permissions,
        _speech = speech ?? stt.SpeechToText(),
        _tts = tts ?? FlutterTts();

  final MicPermissionService _permissions;
  final stt.SpeechToText _speech;
  final FlutterTts _tts;

  final _controller = StreamController<VoiceSnapshot>.broadcast();
  VoiceSnapshot _snapshot = const VoiceSnapshot();

  /// The UI subscribes here; every state change is pushed immediately.
  Stream<VoiceSnapshot> get stream => _controller.stream;
  VoiceSnapshot get current => _snapshot;

  OnUtterance? onUtterance;

  /// Fired when the user starts speaking WHILE AEGIS is talking (barge-in).
  /// The orchestrator uses this to cut TTS + cancel the AI stream instantly.
  void Function()? onBargeIn;

  bool _sttReady = false;
  bool _initInFlight = false;

  /// Locale for recognition & TTS, e.g. "en_US". Set from user settings.
  String localeId = 'en_US';

  // --- lifecycle -----------------------------------------------------------

  /// Idempotent init: permission -> STT engine -> TTS engine.
  /// Returns true if the engine is ready to listen.
  Future<bool> initialize() async {
    if (_sttReady) return true;
    if (_initInFlight) return false;
    _initInFlight = true;
    try {
      // 1) Permission — auto-request if not yet granted.
      final perm = await _permissions.ensureGranted();
      switch (perm) {
        case MicPermissionResult.granted:
          break;
        case MicPermissionResult.denied:
          _emit(_snapshot.copyWith(
            status: VoiceStatus.error,
            blockReason: VoiceBlockReason.permissionNotGranted,
            errorMessage: 'Microphone permission is needed for voice mode.',
          ));
          return false;
        case MicPermissionResult.permanentlyDenied:
        case MicPermissionResult.restricted:
          _emit(_snapshot.copyWith(
            status: VoiceStatus.error,
            blockReason: VoiceBlockReason.permissionPermanentlyDenied,
            errorMessage:
                'Microphone is blocked. Enable it in system settings.',
          ));
          return false;
      }

      // 2) Speech recognition engine.
      _sttReady = await _speech.initialize(
        onStatus: _onSttStatus,
        onError: _onSttError,
        debugLogging: kDebugMode,
      );
      if (!_sttReady) {
        _emit(_snapshot.copyWith(
          status: VoiceStatus.error,
          blockReason: VoiceBlockReason.speechUnavailable,
          errorMessage: 'Speech recognition is unavailable on this device.',
        ));
        return false;
      }

      // 3) TTS engine — configure for responsive, natural playback.
      await _configureTts();

      _emit(_snapshot.copyWith(
        status: VoiceStatus.idle,
        blockReason: VoiceBlockReason.none,
        clearError: true,
      ));
      return true;
    } catch (e) {
      _emit(_snapshot.copyWith(
        status: VoiceStatus.error,
        blockReason: VoiceBlockReason.engineFailure,
        errorMessage: 'Voice engine failed to start: $e',
      ));
      return false;
    } finally {
      _initInFlight = false;
    }
  }

  Future<void> _configureTts() async {
    await _tts.setLanguage(localeId.replaceAll('_', '-'));
    await _tts.setSpeechRate(0.52); // natural, not rushed
    await _tts.setPitch(1.0);
    await _tts.setVolume(1.0);
    // awaitSpeakCompletion makes speak() resolve only when playback ends,
    // so we can flip the state machine back to idle at the right moment.
    await _tts.awaitSpeakCompletion(true);
    _tts.setCompletionHandler(() {
      if (_snapshot.status == VoiceStatus.speaking) {
        _emit(_snapshot.copyWith(status: VoiceStatus.idle));
      }
    });
  }

  // --- listening -----------------------------------------------------------

  /// Start a single hands-free listening turn. Auto-initializes if needed.
  Future<void> startListening() async {
    if (!_sttReady) {
      final ok = await initialize();
      if (!ok) return;
    }
    if (_speech.isListening) return; // guard against double-start

    // Stop any TTS so we don't record our own voice.
    await _tts.stop();

    _emit(_snapshot.copyWith(
      status: VoiceStatus.listening,
      partialTranscript: '',
      blockReason: VoiceBlockReason.none,
      clearError: true,
    ));

    try {
      await _speech.listen(
        onResult: _onSttResult,
        localeId: localeId,
        // Reliability tuning for tablets/phones:
        listenFor: const Duration(seconds: 30), // hard cap per turn
        pauseFor: const Duration(seconds: 3), // end turn after 3s silence
        onSoundLevelChange: _onSoundLevel,
        listenOptions: stt.SpeechListenOptions(
          partialResults: true, // live transcript for responsiveness
          cancelOnError: false, // we handle errors & auto-recover
          listenMode: stt.ListenMode.dictation,
          autoPunctuation: true,
        ),
      );
    } catch (e) {
      _fail(VoiceBlockReason.engineFailure, 'Could not start listening: $e');
    }
  }

  /// Manually stop listening (e.g. push-to-talk release) and finalize.
  Future<void> stopListening() async {
    if (_speech.isListening) {
      await _speech.stop(); // graceful: keeps last recognized result
    }
    if (_snapshot.status == VoiceStatus.listening) {
      _emit(_snapshot.copyWith(status: VoiceStatus.processing));
    }
  }

  /// Hard cancel (discard current utterance).
  Future<void> cancel() async {
    await _speech.cancel();
    _emit(_snapshot.copyWith(status: VoiceStatus.idle, partialTranscript: ''));
  }

  // --- speaking ------------------------------------------------------------

  /// Speak assistant text. Flips to speaking, returns when playback completes.
  Future<void> speak(String text) async {
    if (text.trim().isEmpty) return;
    _emit(_snapshot.copyWith(status: VoiceStatus.speaking));
    try {
      await _tts.speak(text);
    } catch (e) {
      _fail(VoiceBlockReason.engineFailure, 'Speech playback failed: $e');
    }
  }

  Future<void> stopSpeaking() async {
    await _tts.stop();
    if (_snapshot.status == VoiceStatus.speaking) {
      _emit(_snapshot.copyWith(status: VoiceStatus.idle));
    }
  }

  // --- STT callbacks -------------------------------------------------------

  void _onSttResult(dynamic result) {
    final recognized = result.recognizedWords as String;
    final isFinal = result.finalResult as bool;

    if (!isFinal) {
      _emit(_snapshot.copyWith(
        status: VoiceStatus.listening,
        partialTranscript: recognized,
      ));
      return;
    }

    // Final utterance -> processing, then hand off to the AI layer.
    _emit(_snapshot.copyWith(
      status: VoiceStatus.processing,
      finalTranscript: recognized,
      partialTranscript: '',
      soundLevel: 0,
    ));
    if (recognized.trim().isNotEmpty) {
      onUtterance?.call(recognized);
    } else {
      // Heard nothing usable -> recover to idle instead of hanging.
      _emit(_snapshot.copyWith(status: VoiceStatus.idle));
    }
  }

  void _onSoundLevel(double level) {
    // speech_to_text reports roughly -2..10; normalize to 0..1 for the viz.
    final normalized = ((level + 2) / 12).clamp(0.0, 1.0);

    // Barge-in detection: if AEGIS is speaking and the mic picks up sustained
    // energy above a threshold, treat it as the user interrupting.
    if (_snapshot.status == VoiceStatus.speaking && normalized > 0.55) {
      onBargeIn?.call();
    }
    _emit(_snapshot.copyWith(soundLevel: normalized));
  }

  /// Keep a low-power listening pass active during TTS so barge-in can trigger.
  /// (Full-duplex is device-dependent; this best-effort approach works on most
  /// Android hardware. Push-to-talk interruption always works regardless.)
  Future<void> armBargeInListening() async {
    if (!_sttReady || _speech.isListening) return;
    try {
      await _speech.listen(
        onResult: _onSttResult,
        localeId: localeId,
        onSoundLevelChange: _onSoundLevel,
        listenFor: const Duration(seconds: 20),
        pauseFor: const Duration(seconds: 2),
        listenOptions: stt.SpeechListenOptions(
          partialResults: true,
          cancelOnError: false,
          listenMode: stt.ListenMode.dictation,
        ),
      );
    } catch (_) {
      // Barge-in listening is best-effort; ignore failures.
    }
  }

  void _onSttStatus(String status) {
    // Native recognizer emits "listening" / "notListening" / "done".
    if (status == 'done' || status == 'notListening') {
      if (_snapshot.status == VoiceStatus.listening) {
        // Stopped without a final result (silence). Return to idle cleanly.
        _emit(_snapshot.copyWith(status: VoiceStatus.idle, soundLevel: 0));
      }
    }
  }

  void _onSttError(dynamic error) {
    final msg = error.errorMsg as String? ?? 'unknown';
    // "error_no_match" / "error_speech_timeout" are benign — just no speech.
    if (msg == 'error_no_match' || msg == 'error_speech_timeout') {
      _emit(_snapshot.copyWith(
        status: VoiceStatus.idle,
        soundLevel: 0,
        partialTranscript: '',
      ));
      return;
    }
    if (msg == 'error_permission') {
      _fail(VoiceBlockReason.permissionNotGranted,
          'Microphone permission was revoked.');
      _sttReady = false; // force re-init next time
      return;
    }
    // network / busy / client -> transient; surface but keep recoverable.
    _fail(VoiceBlockReason.engineFailure, 'Recognition error: $msg');
  }

  // --- helpers -------------------------------------------------------------

  void _fail(VoiceBlockReason reason, String message) {
    _emit(_snapshot.copyWith(
      status: VoiceStatus.error,
      blockReason: reason,
      errorMessage: message,
      soundLevel: 0,
    ));
  }

  void _emit(VoiceSnapshot s) {
    _snapshot = s;
    if (!_controller.isClosed) _controller.add(s);
  }

  Future<void> dispose() async {
    await _speech.cancel();
    await _tts.stop();
    await _controller.close();
  }
}
