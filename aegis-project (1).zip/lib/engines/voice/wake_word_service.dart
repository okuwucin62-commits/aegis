// AEGIS — Wake-word service (interface + design).
//
// Always-on "Hey AEGIS" detection. On Android this MUST run inside a
// foreground service (see AndroidManifest: foregroundServiceType="microphone")
// with a persistent, user-visible notification — both for OS compliance and
// for user trust ("AEGIS is listening").
//
// Implementation options (Milestone 3):
//   * openWakeWord (open-source, on-device, free) — recommended.
//   * Picovoice Porcupine (free tier, very low CPU) — needs an access key.
// Both run a tiny model locally; NO audio leaves the device until the wake
// word fires and the main STT turn begins.

import 'voice_state.dart';

abstract interface class WakeWordService {
  /// Whether the detector is currently armed and listening in the background.
  bool get isArmed;

  /// Arm the detector. Starts the Android foreground service.
  /// [onDetected] fires when the wake phrase is recognized.
  Future<bool> arm({required void Function() onDetected});

  /// Disarm and stop the foreground service (frees the mic + battery).
  Future<void> disarm();
}

/// No-op default so the app runs before the native detector is wired in.
/// Voice mode still works via tap / push-to-talk without a wake word.
class NoopWakeWordService implements WakeWordService {
  bool _armed = false;

  @override
  bool get isArmed => _armed;

  @override
  Future<bool> arm({required void Function() onDetected}) async {
    // TODO(Milestone 3): start foreground service + on-device detector.
    _armed = false; // honestly report "not armed" until implemented
    return false;
  }

  @override
  Future<void> disarm() async {
    _armed = false;
  }
}

/// Helper for the UI to reflect wake-word state in a VoiceSnapshot.
extension WakeWordSnapshot on VoiceSnapshot {
  VoiceSnapshot withWakeWord(bool armed) => copyWith(wakeWordArmed: armed);
}
