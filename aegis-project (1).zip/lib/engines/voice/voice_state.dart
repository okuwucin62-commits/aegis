// AEGIS — Voice Engine: state machine definitions.
//
// A single source of truth for what the assistant is doing with audio.
// The UI (orb + status label) is driven purely off [VoiceStatus], so there is
// never a mismatch between what the engine is doing and what the user sees.

/// The four user-facing states requested, plus honest internal ones.
enum VoiceStatus {
  /// Not listening. Wake word may still be armed in the background.
  idle,

  /// Actively capturing microphone audio for a user utterance.
  listening,

  /// Utterance captured; running STT / sending to AI / awaiting response.
  processing,

  /// Playing TTS audio back to the user.
  speaking,

  /// A recoverable error occurred (permission denied, no speech, engine fail).
  error,
}

/// Why the engine cannot currently listen (drives the UI's call-to-action).
enum VoiceBlockReason {
  none,

  /// OS microphone permission was never granted.
  permissionNotGranted,

  /// User permanently denied the permission (must open app settings).
  permissionPermanentlyDenied,

  /// Device/platform has no speech recognition available.
  speechUnavailable,

  /// A transient engine or network failure.
  engineFailure,
}

/// Immutable snapshot of the voice subsystem, exposed to the UI.
class VoiceSnapshot {
  final VoiceStatus status;
  final VoiceBlockReason blockReason;

  /// Live partial transcript while [status] == listening.
  final String partialTranscript;

  /// Final recognized text of the last completed utterance.
  final String finalTranscript;

  /// Normalized mic amplitude 0..1 for the waveform visualizer.
  final double soundLevel;

  /// Whether the on-device wake word detector is armed.
  final bool wakeWordArmed;

  /// Human-readable message when [status] == error.
  final String? errorMessage;

  const VoiceSnapshot({
    this.status = VoiceStatus.idle,
    this.blockReason = VoiceBlockReason.none,
    this.partialTranscript = '',
    this.finalTranscript = '',
    this.soundLevel = 0.0,
    this.wakeWordArmed = false,
    this.errorMessage,
  });

  bool get canListen =>
      blockReason == VoiceBlockReason.none ||
      blockReason == VoiceBlockReason.permissionNotGranted;

  VoiceSnapshot copyWith({
    VoiceStatus? status,
    VoiceBlockReason? blockReason,
    String? partialTranscript,
    String? finalTranscript,
    double? soundLevel,
    bool? wakeWordArmed,
    String? errorMessage,
    bool clearError = false,
  }) {
    return VoiceSnapshot(
      status: status ?? this.status,
      blockReason: blockReason ?? this.blockReason,
      partialTranscript: partialTranscript ?? this.partialTranscript,
      finalTranscript: finalTranscript ?? this.finalTranscript,
      soundLevel: soundLevel ?? this.soundLevel,
      wakeWordArmed: wakeWordArmed ?? this.wakeWordArmed,
      errorMessage: clearError ? null : (errorMessage ?? this.errorMessage),
    );
  }
}
