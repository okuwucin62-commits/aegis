# AEGIS — Autonomous Environment & General Intelligence System

An original, JARVIS-inspired **personal AI operating assistant**.
Android-first (phones + tablets); designed to expand to Windows, Linux, macOS, and Web.

> Original code, original branding ("AEGIS"), original UI/UX. Not affiliated with
> any film, character, or trademark.

## What's in this repository (Milestone 0 — Foundation)

| Path | What it is |
|---|---|
| `docs/00_ARCHITECTURE.md` | System design, engine layer, tech decisions + rationale |
| `docs/01_PROJECT_STRUCTURE.md` | Full repo layout & layering rules |
| `docs/02_DATA_MODEL.md` | Database schema (Drift/SQLite), encrypted fields |
| `docs/03_SECURITY.md` | Threat model, envelope encryption, auth, sandbox |
| `docs/04_FEATURE_MATRIX.md` | All 50 requested features rated for feasibility |
| `docs/05_FEASIBILITY.md` | Honest constraints & workarounds |
| `docs/06_ROADMAP.md` | Milestone-by-milestone delivery plan |
| `docs/07_DESIGN_SYSTEM.md` | Colors, type, motion, components |
| `lib/` | Flutter scaffold: theme, AI provider interface, crypto interface, entry point |
| `pubspec.yaml` | Dependencies (Flutter, Riverpod, Drift, crypto, secure storage…) |
| `prototype/index.html` | **Live, interactive UI mock** — open in a browser |

## See it now
Open `prototype/index.html` — the futuristic dashboard (glassmorphism, neon,
animated AI orb, voice visualizer, working navigation). The Flutter theme in
`lib/core/theme/aegis_theme.dart` mirrors these exact tokens.

## Design decisions (short version)
- **Flutter** → one codebase for all six target platforms, GPU-accelerated UI.
- **Pluggable `AiProvider`** → swap cloud/local models without touching UI.
- **Local-first + encrypted** → SQLite with field-level AES-256-GCM, keys in
  hardware Keystore/Keychain, biometric/PIN gate.
- **Clean Architecture + 8 engines** → modular, testable, extensible.

## Honest scope note
28 of 50 features are fully buildable in-house; 15 need API keys/accounts you
own (AI provider, search, OAuth); 7 have documented platform ceilings. Nothing
is impossible. See `docs/04` and `docs/05`.

## Next milestone
Milestone 1 — runnable Flutter shell: boot → security gate → dashboard, theme
implemented, navigation, DB + crypto initialized. See `docs/06_ROADMAP.md`.

## Getting started (when building for real)
```bash
flutter pub get
flutter run            # Android device/emulator
```
You'll add an AI provider key at Milestone 2 (see roadmap).
