# AEGIS — Build & install the APK on your tablet

A complete, buildable Flutter Android app. Follow these steps to get it on your
tablet.

## 1. One-time setup (on a computer)
1. Install **Flutter 3.27 or newer**: https://docs.flutter.dev/get-started/install
2. Run `flutter doctor` and clear any Android toolchain issues.
3. Point Gradle at your SDKs:
   ```bash
   cp android/local.properties.template android/local.properties
   # edit android/local.properties:
   #   flutter.sdk=/absolute/path/to/flutter
   #   sdk.dir=/absolute/path/to/Android/sdk
   ```

## 2. Build the APK
```bash
cd aegis                # folder with pubspec.yaml
flutter pub get
flutter build apk --release
```
Output: `build/app/outputs/flutter-apk/app-release.apk`

> First build downloads Gradle + dependencies and can take several minutes.

## 3. Install on the tablet
- **USB:** `flutter install` (with the tablet connected & USB debugging on), or
- **Manual:** copy `app-release.apk` to the tablet, tap it, allow "install from
  unknown sources", install.

## 4. First run
1. AEGIS opens on the **Dashboard**.
2. Go to **Settings** → paste your OpenAI (or compatible) **API key** → *Save & verify*.
3. **Chat** — type to talk to AEGIS (streaming replies).
4. **Voice** — grant the mic permission → tap/hold the orb → speak.
5. **Tasks / Notes / Reminders** — fully working, encrypted, offline.

## What works in this build (MVP+)
| Area | Status |
|---|---|
| Adaptive tablet UI (rail in landscape, bar in portrait) | ✅ |
| Streaming AI chat (OpenAI-compatible, swappable) | ✅ |
| Voice: STT + TTS + interruption + status states | ✅ (real device) |
| Short-term memory + auto-summarization | ✅ |
| Encrypted local storage (AES-256, key in Keystore) | ✅ |
| Notes / Tasks / Reminders (with real notifications) | ✅ |
| Conversation history persistence | ✅ |
| Device info | ✅ |
| Wake word ("Hey…") | ⏳ tap/hold-to-talk works; wake word is a later add |

## Notes & honest limits
- **Test voice on a real device** — the emulator has no microphone by default.
- **API key required** for chat/voice AI. Tasks/Notes/Reminders work offline
  with no key.
- Release builds are **debug-signed** so `--release` works immediately. Before
  publishing to Play, create your own keystore and set `signingConfig`.
- Reminders use exact-alarm scheduling; Android 13+ prompts for notification
  permission on first reminder.

## Troubleshooting
- **Gradle/desugaring error:** ensure `flutter` is 3.27+ (older Gradle plugin
  versions conflict). `flutter clean && flutter pub get` then rebuild.
- **`flutter.sdk not set`:** you skipped step 1.3 (`local.properties`).
- **Mic does nothing on emulator:** expected — use a physical tablet.
