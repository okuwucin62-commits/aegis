# AEGIS — Feature Matrix (all 50 requested capabilities)

**Feasibility legend**
- 🟢 Fully buildable in Flutter with common packages / our own code.
- 🟡 Buildable but needs an external account / API key / paid service.
- 🟠 Buildable with platform constraints or partial coverage (see note).
- 🔴 Hard constraint — limited on some platforms; honest workaround given.

**Effort:** S (days) · M (1–2 wks) · L (multi-wk)

| # | Feature | Engine | Feas. | Effort | External dependency / note |
|---|---|---|---|---|---|
| 1 | Natural voice conversation | Voice+AI | 🟡 | M | Needs STT/TTS; on-device basic, cloud for quality |
| 2 | Wake word activation | Voice | 🟠 | M | On-device detector (Porcupine free tier / openWakeWord). Always-on mic drains battery; foreground service required on Android |
| 3 | Offline voice commands | Voice | 🟢 | M | On-device STT + intent grammar |
| 4 | Online AI conversations | AI | 🟡 | S | AI provider API key |
| 5 | Long-term memory | Memory | 🟢 | M | Local vector+FTS store |
| 6 | Short-term memory | Memory | 🟢 | S | Rolling buffer + summarizer |
| 7 | File management | Data | 🟢 | M | Scoped storage on Android 11+ |
| 8 | Calendar integration | Data/API | 🟡 | M | Device calendar (free) or Google Calendar OAuth |
| 9 | Reminder system | Automation | 🟢 | S | Local notifications + scheduler |
| 10 | Notes | Data | 🟢 | S | Local, encrypted |
| 11 | Email assistant | API | 🟡 | L | Gmail/Outlook OAuth + scopes |
| 12 | Browser assistant | AI+Plugin | 🟠 | M | In-app webview; can't control external browsers |
| 13 | Internet research | AI+Tools | 🟡 | M | Search API (Brave/Bing/SerpAPI) |
| 14 | Image generation | AI | 🟡 | S | Image model API key |
| 15 | Image analysis | AI | 🟡 | S | Vision-capable model API |
| 16 | PDF analysis | AI+Data | 🟢 | M | Local text extract + AI summarize |
| 17 | Document creation | Data | 🟢 | M | Generate .docx (via templating) |
| 18 | Spreadsheet creation | Data | 🟢 | M | Generate .xlsx |
| 19 | Presentation generation | Data | 🟢 | M | Generate .pptx |
| 20 | Code generation | AI | 🟡 | S | AI provider |
| 21 | Code debugging | AI | 🟡 | S | AI provider |
| 22 | Project management | Domain | 🟢 | M | Tasks/projects module |
| 23 | Task planning | AI+Domain | 🟢 | M | AI decomposes goals → tasks |
| 24 | Trading assistant | AI+API | 🟡 | L | Market-data API; **info only, not advice** (compliance) |
| 25 | Business advisor | AI | 🟡 | S | AI provider + memory |
| 26 | Financial calculations | Domain | 🟢 | S | Pure Dart (no external dep) |
| 27 | Translation | AI/API | 🟡 | S | AI or translation API; some on-device |
| 28 | Live search | AI+Tools | 🟡 | M | Search API |
| 29 | Automation workflows | Automation | 🟢 | L | Trigger/condition/action engine |
| 30 | Smart notifications | Automation | 🟢 | M | Local + rules |
| 31 | Device control | Platform | 🟠 | L | Limited by OS sandbox; intents/settings deep-links, Tasker-style where allowed |
| 32 | Camera understanding | Voice/AI | 🟡 | M | Camera + vision model |
| 33 | OCR | Data | 🟢 | S | On-device ML Kit text recognition |
| 34 | QR scanner | Data | 🟢 | S | mobile_scanner package |
| 35 | Clipboard assistant | Platform | 🟠 | S | Android 10+ restricts background clipboard reads |
| 36 | Widget support | Platform | 🟢 | M | Home-screen widgets (home_widget pkg) |
| 37 | Multi-language support | Core | 🟢 | M | Flutter l10n (ARB) |
| 38 | Plugin system | Plugin | 🟢 | L | Manifest + sandbox + Host API |
| 39 | API integrations | Data | 🟢 | M | Generic connector framework |
| 40 | Local AI support | AI | 🟠 | L | llama.cpp/Gemma via FFI; quality/size limited on phones |
| 41 | Cloud AI support | AI | 🟡 | S | Provider key |
| 42 | Glassmorphism UI | UI | 🟢 | M | BackdropFilter + custom theme |
| 43 | Neon blue accents | UI | 🟢 | S | Theme tokens |
| 44 | Smooth animations | UI | 🟢 | M | Implicit/explicit animations, Rive optional |
| 45 | Voice visualization | UI | 🟢 | M | CustomPainter waveform from mic amplitude |
| 46 | AI status indicator | UI | 🟢 | S | State-driven orb |
| 47 | Floating AI assistant | UI/Platform | 🟠 | M | Android overlay (SYSTEM_ALERT_WINDOW); not on iOS |
| 48 | E2E encryption / secure storage | Security | 🟢 | L | Our crypto layer |
| 49 | Biometric + PIN | Security | 🟢 | S | local_auth |
| 50 | Encrypted backups | Security | 🟢 | M | Our backup format |

## Summary
- 🟢 Fully buildable now: **28**
- 🟡 Buildable, needs your API key/account: **15**
- 🟠 Platform-constrained (honest partial): **7**
- 🔴 Blocked: **0** — everything has a real path.

**The 15 🟡 items are the ones requiring you to supply credentials.** Nothing
is impossible; several just need accounts you control (AI provider, search API,
OAuth apps). I build clean interfaces + setup docs for each per your choice.
