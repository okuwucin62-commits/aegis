# AEGIS — Repository Structure

Feature-first inside Clean Architecture. Each feature owns its
`presentation / domain / data` slices; shared kernel lives in `core/` and
the cross-cutting engines live in `engines/`.

```
aegis/
├── android/                      # Android host project (Gradle, manifest, native)
├── ios/                          # (future)
├── windows/ linux/ macos/ web/   # (future targets, Flutter-generated)
│
├── lib/
│   ├── main.dart                 # Entry: bootstrap DI, security gate, router
│   ├── app.dart                  # Root MaterialApp.router + theme
│   │
│   ├── core/                     # Shared kernel — no feature depends the other way
│   │   ├── theme/                # AegisTheme: colors, glass, neon, motion tokens
│   │   ├── router/               # go_router config + guards
│   │   ├── di/                   # Riverpod providers wiring
│   │   ├── errors/               # Failure types, Result<T>
│   │   ├── utils/                # formatters, extensions, logger
│   │   └── constants/
│   │
│   ├── engines/                  # The kernel modules (see 00_ARCHITECTURE)
│   │   ├── ai/
│   │   │   ├── ai_provider.dart          # abstract interface
│   │   │   ├── model_router.dart
│   │   │   ├── tool_dispatcher.dart
│   │   │   └── providers/
│   │   │       ├── openai_provider.dart
│   │   │       ├── anthropic_provider.dart
│   │   │       ├── gemini_provider.dart
│   │   │       └── local_llm_provider.dart
│   │   ├── memory/
│   │   │   ├── memory_service.dart
│   │   │   ├── vector_store.dart
│   │   │   └── summarizer.dart
│   │   ├── voice/
│   │   │   ├── voice_engine.dart
│   │   │   ├── stt_service.dart
│   │   │   ├── tts_service.dart
│   │   │   └── wake_word_service.dart
│   │   ├── plugin/
│   │   │   ├── plugin_engine.dart
│   │   │   ├── plugin_manifest.dart
│   │   │   └── host_api.dart
│   │   ├── automation/
│   │   │   ├── automation_engine.dart
│   │   │   ├── rule.dart
│   │   │   └── triggers/
│   │   └── security/
│   │       ├── crypto_service.dart
│   │       ├── key_manager.dart
│   │       ├── auth_gate.dart
│   │       ├── permission_broker.dart
│   │       └── audit_log.dart
│   │
│   ├── data/                     # Infrastructure
│   │   ├── db/
│   │   │   ├── database.dart      # Drift database
│   │   │   ├── tables/
│   │   │   └── daos/
│   │   ├── secure/               # secure storage wrapper
│   │   └── remote/               # http clients, api sdks
│   │
│   ├── domain/                   # Enterprise rules (pure Dart)
│   │   ├── entities/             # Conversation, Message, MemoryItem, Task...
│   │   ├── repositories/         # abstract repos
│   │   └── usecases/             # SendMessage, RecallMemory, CreateTask...
│   │
│   └── features/                 # Presentation, one folder per screen/domain
│       ├── dashboard/
│       ├── chat/
│       ├── voice_mode/
│       ├── memory_manager/
│       ├── plugin_manager/
│       ├── automation_center/
│       ├── settings/
│       └── floating_assistant/
│
├── assets/
│   ├── fonts/
│   ├── icons/
│   └── plugins/                  # bundled first-party plugins
│
├── test/                         # unit + widget tests mirror lib/
├── integration_test/
│
├── pubspec.yaml
├── analysis_options.yaml         # strict lints
└── docs/                         # this blueprint
```

### Layering enforcement
- `domain/` imports nothing from `data/`, `engines/`, or `features/`.
- `features/` may import `domain/` + `core/` only (never `data/` directly).
- Dependency injection wires concrete `data`/`engine` implementations to
  domain interfaces at app start (`core/di`).
- A lint rule (`import_lint` / custom) enforces these boundaries in CI.
