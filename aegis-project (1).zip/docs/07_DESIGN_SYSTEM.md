# AEGIS — Design System (Original Branding)

Futuristic "AI operating system" feel. Fully original — no copyrighted marks,
names, or likenesses. Aesthetic = deep space glass + electric cyan/blue neon.

## Brand
- **Name:** AEGIS
- **Wordmark:** geometric, wide letter-spacing, thin weight + one accent glyph.
- **Symbol:** a hexagonal "core" ring with an inner pulse (the AI status orb).
- **Voice/tone:** calm, precise, quietly confident.

## Color tokens (dark-first)
| Token | Hex | Use |
|---|---|---|
| bg.base | `#05070D` | app background (near-black navy) |
| bg.elevated | `#0B1020` | cards behind glass |
| glass.fill | `rgba(255,255,255,0.06)` | frosted panel fill |
| glass.stroke | `rgba(120,200,255,0.18)` | glass edge highlight |
| neon.primary | `#22D3FF` | primary accent (electric cyan) |
| neon.secondary | `#3B82F6` | secondary accent (blue) |
| neon.glow | `rgba(34,211,255,0.45)` | shadow/glow color |
| text.primary | `#EAF6FF` | main text |
| text.muted | `#8FA3B8` | secondary text |
| state.ok | `#34D399` | success/online |
| state.warn | `#FBBF24` | warning |
| state.err | `#F87171` | error |

Light theme = inverted surfaces with reduced glow (accessibility toggle).

## Typography
- Display/UI: a geometric sans (e.g. "Sora"/"Space Grotesk" — bundled OFL font).
- Mono (code): "JetBrains Mono".
- Scale (dp): 34 / 28 / 22 / 18 / 16 / 14 / 12, line-height 1.35.

## Elevation & glass
- Glass panel = `BackdropFilter(blur 18–24)` + glass.fill + 1px glass.stroke +
  16–24 radius + soft neon inner glow on focus.
- Never more than 2 stacked blurs on screen at once (performance budget).

## Motion tokens
| Token | Duration | Curve | Use |
|---|---|---|---|
| motion.fast | 120ms | easeOut | taps, toggles |
| motion.base | 240ms | easeInOutCubic | page/element transitions |
| motion.slow | 480ms | easeInOutCubic | hero/orb |
| motion.pulse | 1600ms loop | sine | idle orb breathing |

Respect `prefers-reduced-motion` / OS "remove animations".

## Signature components
- **AI Status Orb:** hex ring + animated core. States: idle (slow breathe),
  listening (waveform), thinking (rotating arcs), speaking (pulsing rings),
  error (red flicker).
- **Voice Visualizer:** live amplitude waveform (CustomPainter) fed by mic RMS.
- **Glass Nav Rail / Bottom Bar:** frosted, neon active indicator.
- **Command Bar:** center-screen glass input with model chip + mic + send.

## Accessibility
- WCAG AA contrast for text on glass (verify each surface).
- Min 48dp touch targets, focus outlines, screen-reader labels, scalable text.

## Performance budget
- Cold start < 2s to interactive shell (mid-range device).
- 60fps floor / 120fps target on capable displays.
- Max 2 concurrent backdrop blurs; prefer pre-rendered glow where static.
