# AEGIS — Security Design

Security is a cross-cutting layer, not a feature. Threat model first, then controls.

## 1. Threat model (what we defend against)

| Asset | Threats | Priority |
|---|---|---|
| Conversations, notes, memory | Device theft, malware reading app storage, backups leaking | High |
| API keys / credentials | Extraction from storage, logs, memory dumps | High |
| Biometric/PIN gate | Bypass, replay | High |
| Plugins | Malicious plugin exfiltrating data or abusing device APIs | High |
| Network traffic | MITM, TLS downgrade | Medium |
| Automation w/ device control | Privilege abuse, unintended actions | Medium |

Out of scope for v1: defending against a fully rooted/jailbroken device with
an active attacker (we reduce but cannot eliminate that risk; we detect &
warn).

## 2. Encryption architecture (envelope pattern)

```
Hardware Keystore/Keychain
        │ stores
        ▼
   KEK (Key Encryption Key)  ── never leaves secure hardware
        │ wraps/unwraps
        ▼
   DEK (Data Encryption Key)  ── kept in memory only while unlocked
        │ AES-256-GCM
        ▼
   Field-level ciphertext in SQLite (🔒 columns) + encrypted file blobs
```

- **Algorithm:** AES-256-GCM (authenticated). Random 96-bit nonce per record.
- **KDF (for PIN-derived key):** Argon2id (memory-hard) → wrapping key.
- **At rest:** all 🔒 columns + attachment files encrypted with DEK.
- **In transit:** TLS 1.2+ only; certificate pinning for first-party endpoints.
- **In use:** DEK zeroized from memory on lock/background timeout.

## 3. Authentication gate

- **Biometric** (fingerprint/face) via `local_auth` — unlocks DEK via Keystore.
- **PIN fallback** — Argon2id-derived key unwraps DEK; rate-limited + lockout
  with exponential backoff after failed attempts.
- **Auto-lock** after configurable idle timeout and on app background.
- No secret is recoverable without biometric/PIN → true zero-knowledge at rest.

## 4. Permission broker

Every sensitive capability (camera, mic, files, location, contacts, network,
device control) is mediated:
1. OS permission (Android runtime permission).
2. AEGIS in-app grant (user consent per capability).
3. Per-plugin grant (a plugin never inherits app permissions implicitly).

Denied-by-default. All grants logged to the audit log.

## 5. Plugin sandbox

- Plugins declare needed permissions in `plugin.json`; user approves at install.
- Plugins call only the **Host API** (a capped, audited facade) — no direct
  DB, filesystem, or platform-channel access.
- Resource + rate limits; a misbehaving plugin can be killed & quarantined.
- (Roadmap) run untrusted plugin logic in an isolated Dart isolate / WASM.

## 6. Encrypted backups

- Backup = encrypted blob (DEK-encrypted content + KEK-wrapped DEK).
- Restored only on a device that can unwrap via the user's biometric/PIN or a
  user-exported recovery key (shown once, never stored).
- Optional target: user's own cloud drive. AEGIS servers never hold plaintext.

## 7. Secure logging & privacy

- Logs never contain 🔒 content, keys, or full prompts by default.
- Crash reports scrub PII.
- Audit log is append-only and user-viewable in the Memory/Security screen.

## 8. Checklist (implementation acceptance)

- [ ] KEK created in hardware-backed store on first run
- [ ] DEK generated, wrapped, persisted; unwrapped only after auth
- [ ] All 🔒 columns encrypted on write / decrypted on read via CryptoService
- [ ] Biometric + PIN gate with lockout & idle auto-lock
- [ ] Permission broker denies by default; grants audited
- [ ] TLS pinning for first-party APIs
- [ ] Plugin install consent + Host-API-only access
- [ ] Encrypted backup/restore round-trip test passes
- [ ] Memory zeroization on lock verified
- [ ] No secrets in logs (automated scan in CI)
