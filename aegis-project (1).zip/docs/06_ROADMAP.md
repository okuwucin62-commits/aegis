# AEGIS — Delivery Roadmap

A realistic, milestone-based plan from zero to production. Each milestone ends
with something runnable and testable — no big-bang integration.

## Milestone 0 — Foundation  ← (this session)
- [x] Architecture blueprint (this docs set)
- [x] Repository structure & layering rules
- [x] Data model + DB schema
- [x] Security design + threat model
- [x] Feature matrix + feasibility
- [x] `AiProvider` interface + design theme spec
- [x] Live UI prototype of the dashboard (see /prototype)
- [x] pubspec + analysis options + starter Dart scaffolding

## Milestone 1 — Runnable shell (1–2 wks)
- App boots → security gate (biometric/PIN) → dashboard
- Theme system (glass/neon/motion) implemented
- go_router navigation across all shell screens (empty states)
- Drift DB initialized + CryptoService + Keystore-backed keys
- CI: lint, format, unit-test gates

## Milestone 2 — Chat + Memory core  ← (DONE this session)
- [x] `AiProvider` (OpenAI-compatible) wired; streaming SSE
- [x] Conversation orchestrator: full voice loop
- [x] Sentence-level streaming TTS (low latency) — unit-tested
- [x] Barge-in interruption (voice + tap)
- [x] Short-term buffer + auto-summarization
- [x] Long-term memory interface (recall injection) — vector store next
- [x] Model switching + API-key settings UI
- [ ] Long-term vector memory persistence (next step)
- [ ] Conversation persistence to encrypted DB (next step)

## Milestone 3 — Tools, Agents & Memory layers  ← (DONE this session)
- [x] Universal Tool contract (permission + risk tiers)
- [x] Secure ToolRegistry (validate→permit→confirm→audit→run)
- [x] PermissionBroker (zero-trust) + append-only AuditLog
- [x] Built-in tools: finance calculator, web search, reminders
- [x] Autonomous AgentExecutor (plan → parallel DAG execute w/ retries → synthesize)
- [x] Tool-calling inside voice/chat conversations
- [x] Long-term VectorMemory (offline cosine + hybrid ranking)
- [x] KnowledgeGraph (projects/people/preferences, searchable)
- [x] Unit tests + verified core algorithms

## Milestone 3b — Voice hardening (partly done earlier)
- [x] STT/TTS, push-to-talk, voice visualization, interruption
- [ ] Wake word native detector (foreground service, opt-in)
- [ ] Offline command grammar

## Milestone 4 — Productivity suite (3–4 wks)
- Notes, Tasks/Projects, Reminders, Calendar (device)
- Document/Spreadsheet/Presentation generation
- PDF analysis, OCR, QR scanner

## Milestone 5 — Intelligence tools (3–4 wks)
- Internet research + live search (tool-calling)
- Image generation & analysis
- Translation, financial calculators, business/trading info modules

## Milestone 6 — Extensibility (3–4 wks)
- Plugin engine + sandbox + Host API + Plugin Manager UI
- Automation engine (trigger/condition/action) + Automation Center
- API integration connectors

## Milestone 7 — Platform polish & hardening (ongoing)
- Widgets, floating assistant, smart notifications
- Encrypted backup/restore, permission center, audit viewer
- Performance passes (startup, battery, memory), accessibility, l10n
- Expand to desktop + web targets

## Cross-cutting, every milestone
- Tests (unit/widget/integration), docs, security review, perf budget checks.

## What you (the owner) provide, and when
| When | You provide |
|---|---|
| M2 | AI provider API key |
| M5 | Search API key, image model key |
| M4/M6 | Google/Microsoft OAuth app (calendar/email) |
| M7 | Signing keys, store accounts, cloud backup target |
