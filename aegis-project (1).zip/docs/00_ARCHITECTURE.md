# AEGIS — Architecture Blueprint

> **AEGIS** = *Autonomous Environment & General Intelligence System*
> An original, JARVIS-inspired personal AI operating assistant.
> Android-first (phones + tablets), expandable to Windows, Linux, macOS, and Web.

**Status:** Foundation / Milestone 0
**Framework:** Flutter (Dart) — single codebase, all target platforms
**Architecture style:** Clean Architecture + feature-first modularization + layered engines

---

## 1. Why these technology choices

| Decision | Choice | Rationale | Rejected alternatives |
|---|---|---|---|
| App framework | **Flutter 3.x** | One codebase → Android/iOS/Win/Linux/macOS/Web. GPU-accelerated rendering makes glassmorphism + neon + 120fps animation realistic. Mature ecosystem for the hard parts (secure storage, biometrics, audio, SQLite, background work). | Native Kotlin (no cross-platform), React Native (weak on-device AI/audio) |
| Language | **Dart** (null-safe) | Native to Flutter; AOT-compiled to fast native code on mobile/desktop. | — |
| AI layer | **Pluggable `AiProvider` abstraction** | "Switch between models" + "local and cloud" are hard requirements. An interface prevents vendor lock-in. Cloud-first for quality; local seam ready. | Hard-coding a single provider |
| Local DB | **Drift (SQLite)** + **Isar** consideration | Relational integrity for structured data (tasks, notes, calendar); FTS5 for memory search. | Raw sqflite (too low-level), Hive (weak querying) |
| Vector memory | **sqlite-vec / on-device embeddings** | Long-term semantic memory needs vector similarity search, kept local for privacy. | Remote vector DB (privacy + offline concerns) |
| State management | **Riverpod 2** | Compile-safe DI, testable, no BuildContext coupling, great for layered engines. | Provider (less safe), Bloc (more boilerplate) |
| Secure storage | **flutter_secure_storage** (Keystore/Keychain) | Hardware-backed key storage for the encryption master key. | SharedPreferences (insecure) |
| Encryption | **AES-256-GCM** via `cryptography` pkg | Authenticated encryption for data at rest; envelope encryption pattern. | Custom crypto (never roll your own) |
| Navigation | **go_router** | Declarative, deep-linkable, works across platforms incl. web URLs. | Navigator 1.0 (imperative) |

---

## 2. High-level system diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                          PRESENTATION LAYER                           │
│  Dashboard · Chat · Voice Mode · Memory Mgr · Plugin Mgr ·           │
│  Automation Center · Settings · Floating Assistant · Widgets         │
│                  (Flutter widgets + Riverpod state)                    │
└───────────────────────────────┬─────────────────────────────────────┘
                                 │  (calls use-cases only, never engines directly)
┌───────────────────────────────▼─────────────────────────────────────┐
│                          DOMAIN LAYER                                  │
│  Entities · Use-Cases (Interactors) · Repository Interfaces           │
│  Pure Dart, zero framework dependencies — the stable core             │
└───────────────────────────────┬─────────────────────────────────────┘
                                 │
┌───────────────────────────────▼─────────────────────────────────────┐
│                           ENGINE LAYER  (the "kernel")                 │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐   │
│  │ AI Engine│ │  Memory  │ │  Voice   │ │  Plugin  │ │Automation│   │
│  │(providers│ │  System  │ │  Engine  │ │  Engine  │ │  Engine  │   │
│  │ router)  │ │(vec+kv)  │ │(STT/TTS/ │ │(sandbox) │ │(triggers)│   │
│  │          │ │          │ │ wakeword)│ │          │ │          │   │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘   │
└───────────────────────────────┬─────────────────────────────────────┘
                                 │
┌───────────────────────────────▼─────────────────────────────────────┐
│                    DATA + INFRASTRUCTURE LAYER                         │
│  Drift/SQLite · Secure Storage · File System · HTTP clients ·         │
│  Platform Channels (camera, notifications, biometrics) · API SDKs      │
└───────────────────────────────┬─────────────────────────────────────┘
                                 │
┌───────────────────────────────▼─────────────────────────────────────┐
│                        SECURITY LAYER (cross-cutting)                  │
│  Crypto service · Key management · Auth gate · Permission broker ·     │
│  Audit log · Encrypted backup                                         │
└─────────────────────────────────────────────────────────────────────┘
```

**Golden rule (dependency direction):** Presentation → Domain ← Engine/Data.
The Domain layer depends on *nothing*. Everything depends on the Domain's interfaces.
This is what makes features pluggable and the app testable.

---

## 3. The eight engines (module contracts)

Each engine is an independent module exposing a narrow interface. Swapping an
implementation (e.g. cloud AI → local AI) never touches the UI.

### 3.1 AI Engine
- `AiProvider` interface: `chat()`, `stream()`, `embed()`, `capabilities`.
- `ModelRouter`: picks provider by capability, cost, availability, user setting.
- Implementations: `OpenAiProvider`, `AnthropicProvider`, `GeminiProvider`, `LocalLlmProvider` (llama.cpp / gemma via FFI).
- Tool/function-calling dispatcher → routes model tool calls to skills/plugins.

### 3.2 Memory System
- **Short-term:** rolling conversation buffer with token-budget summarization.
- **Long-term:** vector store (embeddings) + FTS5 keyword search (hybrid retrieval).
- **Structured facts:** key–value "user profile" (name, preferences, timezone).
- `MemoryService.recall(query)` → ranked context injected into prompts.

### 3.3 Voice Engine
- STT (speech-to-text): on-device first, cloud fallback.
- TTS (text-to-speech): platform TTS + optional neural cloud voice.
- Wake-word: on-device detector (Porcupine-style) — see `05_FEASIBILITY.md`.
- VAD (voice activity detection) for hands-free turn-taking.

### 3.4 Plugin Engine
- Manifest-driven plugins (`plugin.json`): declared permissions + capabilities.
- Sandboxed execution; plugins call a capped Host API only.
- Registry, enable/disable, per-plugin permission grants.

### 3.5 Automation Engine
- **Trigger → Condition → Action** rules ("if this, then that").
- Triggers: time, location, event, voice, device state.
- Runs via background workers (WorkManager on Android).

### 3.6 Database
- Drift schema (see `02_DATA_MODEL.md`), migrations, DAOs.
- All sensitive columns encrypted at the field level.

### 3.7 Security Layer
- Envelope encryption, biometric/PIN gate, permission broker, audit log.
- See `03_SECURITY.md`.

### 3.8 Sync/Backup (later)
- Encrypted backup blobs; user-held key; optional cloud drive target.

---

## 4. Feature → Engine → Feasibility map

See `04_FEATURE_MATRIX.md` for the full 50-feature breakdown with
feasibility ratings and external-dependency notes.

---

## 5. Repository structure

See `01_PROJECT_STRUCTURE.md`.

---

## 6. Delivery roadmap

See `06_ROADMAP.md`. Milestone 0 (this session) delivers the blueprint,
scaffold, data model, security design, provider interface, and a live UI
prototype of the dashboard.
