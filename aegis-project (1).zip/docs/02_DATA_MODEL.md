# AEGIS — Data Model & Database Schema

Local-first. SQLite via Drift. Sensitive text columns are stored as
AES-256-GCM ciphertext (see `03_SECURITY.md`) — noted as 🔒 below.

## Entity-relationship overview

```
User (1) ──< Conversation (1) ──< Message
User (1) ──< MemoryItem                       (vector + fts)
User (1) ──< Task ──< Subtask
User (1) ──< Note
User (1) ──< CalendarEvent
User (1) ──< Reminder
User (1) ──< Plugin (installed) ──< PluginPermission
User (1) ──< AutomationRule ──< RuleAction
User (1) ──< AuditLogEntry
User (1) ──< ApiCredential  (🔒 encrypted)
```

## Tables

### users
| column | type | notes |
|---|---|---|
| id | TEXT PK | uuid |
| display_name | TEXT | |
| locale | TEXT | e.g. en-US |
| timezone | TEXT | IANA |
| created_at | INTEGER | epoch ms |
| prefs_json | TEXT 🔒 | UI + assistant preferences |

### conversations
| id PK | title | model_id | created_at | updated_at | archived (bool) | pinned (bool) |

### messages
| column | type | notes |
|---|---|---|
| id | TEXT PK | |
| conversation_id | TEXT FK | |
| role | TEXT | user \| assistant \| system \| tool |
| content | TEXT 🔒 | |
| tokens | INTEGER | for budget accounting |
| tool_call_json | TEXT | nullable |
| created_at | INTEGER | |

### memory_items  (long-term semantic memory)
| column | type | notes |
|---|---|---|
| id | TEXT PK | |
| kind | TEXT | fact \| preference \| event \| summary |
| content | TEXT 🔒 | |
| embedding | BLOB | float32 vector (e.g. 768d) |
| source_ref | TEXT | conversation/message id |
| importance | REAL | 0..1 decay-weighted |
| created_at | INTEGER | |
| last_accessed | INTEGER | for recency ranking |
> FTS5 virtual table `memory_fts(content)` mirrors decrypted content **in a
> secured in-memory index only** — see security note. Hybrid recall =
> α·cosine(vector) + β·bm25(fts) + γ·recency + δ·importance.

### tasks / subtasks
tasks: | id | title | description🔒 | status(todo/doing/done/blocked) | priority(0-3) | due_at | project_id | created_at |
subtasks: | id | task_id FK | title | done(bool) | order |

### notes
| id | title | body🔒 | tags_json | pinned | created_at | updated_at |

### calendar_events
| id | title | description🔒 | start_at | end_at | all_day | location | recurrence_rule (RRULE) | external_id | source(local/google/…) |

### reminders
| id | text🔒 | remind_at | repeat_rule | done | linked_task_id |

### plugins
| id | name | version | manifest_json | enabled(bool) | installed_at | source_url |

### plugin_permissions
| id | plugin_id FK | permission | granted(bool) | granted_at |

### automation_rules
| id | name | enabled | trigger_json | condition_json | created_at |

### rule_actions
| id | rule_id FK | action_type | params_json | order |

### api_credentials
| id | provider | label | secret🔒 | created_at | last_used |
> Secrets encrypted with the master key; master key in Keystore/Keychain.

### audit_log
| id | ts | actor(user/plugin/system) | action | target | metadata_json |
> Append-only. Records permission grants, key use, data export, plugin actions.

## Migrations
- Drift schema version starts at 1.
- Every schema change bumps `schemaVersion` and adds a stepwise migration.
- Migration tests assert forward-migration from each prior version.

## Encryption at the field level
- 🔒 columns store `nonce(12B) || ciphertext || tag(16B)`, base64.
- Data Encryption Key (DEK) is per-install, wrapped by a Key Encryption Key
  (KEK) held in hardware-backed secure storage. Rotating the KEK re-wraps the
  DEK without re-encrypting all rows (envelope encryption).
