# AEGIS — Feasibility & Honest Constraints

This document exists because your brief demanded accuracy over speculation.
Here is exactly where reality bites, and the pragmatic workaround for each.

## 1. Always-on wake word ("Hey AEGIS")
- **Constraint:** Continuous mic listening is battery- and privacy-sensitive.
  Android requires a **foreground service** with a persistent notification;
  true low-power always-on hotword usually needs vendor DSP APIs unavailable
  to third-party apps.
- **Workaround:** On-device wake-word model (openWakeWord / Porcupine free
  tier) running in a foreground service, user-toggleable, with a visible
  "listening" indicator. Push-to-talk and quick-tile fallback always available.
- **iOS:** No third-party always-on hotword. Use Siri Shortcut → open app.

## 2. Device control
- **Constraint:** Mobile OSes sandbox apps. You cannot freely toggle arbitrary
  system settings or control other apps like a desktop automation tool.
- **What IS possible:** deep-link intents, settings shortcuts, notifications,
  media controls, launching apps, Android Quick Settings tiles, and (with
  Accessibility Service consent) Tasker-style automation. Full "device control"
  is a spectrum — we implement the allowed slice and document the rest.

## 3. Floating assistant overlay
- **Android:** Yes, via `SYSTEM_ALERT_WINDOW` (draw over other apps) permission.
- **iOS/web:** Not permitted → use Picture-in-Picture / app-scoped bubble.

## 4. Clipboard assistant
- **Constraint:** Android 10+ blocks background clipboard reads. Foreground
  reads only.
- **Workaround:** Clipboard assistant works while AEGIS is foreground or via a
  share-sheet action ("Send to AEGIS").

## 5. Email / Calendar / cloud integrations
- **Constraint:** Require OAuth client registration (you create the app in
  Google/Microsoft consoles) and, for Gmail restricted scopes, a Google
  security review before public release.
- **Workaround:** Build against device calendar + IMAP/SMTP first (fewer
  gates), add OAuth providers behind the same interface.

## 6. Local (on-device) LLM
- **Constraint:** Phone-class hardware runs only small quantized models
  (1–3B). Quality is far below cloud models; large models need lots of RAM.
- **Workaround:** Ship a small local model for offline/basic + private tasks;
  route complex reasoning to cloud when available. The `ModelRouter` does this
  automatically based on capability + connectivity + user preference.

## 7. Trading assistant (compliance)
- **Constraint:** Automated financial *advice* is regulated in most
  jurisdictions.
- **Design:** AEGIS provides **information, analysis, and calculations with
  clear disclaimers** — never personalized investment advice or auto-trading.
  This is a deliberate product/legal decision, not a technical limit.

## Bottom line
Zero features are impossible. 28 are fully in our hands, 15 need credentials
you own, 7 have honest platform ceilings with documented workarounds. This is
a buildable product with a clear-eyed scope.
