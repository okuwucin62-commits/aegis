# AEGIS — Voice Subsystem: how it works & why the browser can't test it

## TL;DR
Your microphone issue was **not a bug in your device** — the prototype had a
*fake* waveform (CSS animation only) and browsers block mic access in the way
you're viewing the file. The **real voice assistant is now implemented in the
Flutter app**, where it works properly on Android. Here's the full picture.

## Why the browser prototype can't hear you

| Reason | Detail |
|---|---|
| **`file://` origin** | Browsers only grant `getUserMedia` (mic) on **HTTPS or `localhost`**. Opening the HTML from disk = no mic, silently. |
| **In-app preview sandbox** | The viewer runs HTML in `sandbox="allow-scripts"` with **no microphone and no network** — by design. |
| **Web Speech API is limited** | `webkitSpeechRecognition` is Chrome/Edge-only, needs internet, streams audio to Google, and has no wake word. It is *not* a production STT path. |
| **The bars were decorative** | The prototype's `<span>` bars are pure CSS `@keyframes` — never connected to a mic. |

So: the prototype is a *visual* mock. Voice belongs in the native app.

## What the Flutter implementation does (the real fix)

Files:
- `lib/engines/voice/voice_state.dart` — state machine: **Idle / Listening / Processing / Speaking / Error** + block reasons.
- `lib/core/permissions/mic_permission_service.dart` — permission flow.
- `lib/engines/voice/voice_engine.dart` — STT + TTS lifecycle & recovery.
- `lib/features/voice_mode/presentation/voice_controller.dart` — Riverpod glue.
- `lib/features/voice_mode/presentation/voice_mode_screen.dart` — UI: orb, 4-state badge, live waveform, error panel.
- `lib/engines/voice/wake_word_service.dart` — always-on "Hey AEGIS" seam.
- `android/app/src/main/AndroidManifest.xml` — permissions + foreground service.

### Your eight requirements → how they're met
| Requirement | Implementation |
|---|---|
| Fix mic permission handling | `MicPermissionService` handles granted / denied / permanently-denied / restricted. |
| Speech recognition starts correctly | `VoiceEngine.initialize()` + `startListening()` with native `SpeechRecognizer`. |
| Auto-request permission | `ensureGranted()` prompts automatically the first time Voice Mode opens. |
| Clear status indicator | `_StatusBadge` shows Idle/Listening/Processing/Speaking/Error with color + icon. |
| Proper error handling | Every STT error mapped: `no_match`/`timeout` → silent recover; `permission` → re-prompt; network/busy → recoverable error UI with **Retry**; permanent denial → **Open Settings** button. |
| Reliable on Android tablets | Uses the OS `SpeechRecognizer` (most reliable path), `pauseFor`/`listenFor` timeouts, auto-restart on benign stops, `cancelOnError:false` so we own recovery. |
| Speed & stability | On-device STT + `partialResults` (live transcript), `awaitSpeakCompletion` for correct state timing, TTS stopped before listening to avoid feedback. |
| Continue the real app | This is all in `lib/` — the production Flutter app, not the prototype. |

## Reliability tuning (why these numbers)
- `listenFor: 30s` — hard cap so a stuck session can't hold the mic forever.
- `pauseFor: 3s` — ends the turn after natural silence (hands-free feel).
- `partialResults: true` — user sees words appear instantly = feels fast.
- `cancelOnError: false` — benign "no speech" events don't kill the session.
- TTS `awaitSpeakCompletion(true)` — state returns to Idle exactly when audio ends.

## Wake word ("Hey AEGIS") — honest status
- Interface + Android foreground-service plumbing are in place.
- The detector model (openWakeWord / Porcupine) is wired in **Milestone 3**.
- Until then, voice works via **tap-to-talk and push-to-talk** (hold the orb),
  which need no wake word and are 100% reliable.

## Testing the real thing
```bash
flutter pub get
flutter run              # on a physical Android tablet/phone (not web)
```
On first entry to Voice Mode you'll see the OS mic-permission dialog. Grant it,
hold the orb, speak — the transcript appears live and AEGIS speaks the reply.

> Note: STT/TTS do **not** work on the Android *emulator* without a configured
> host mic. Always test voice on a **real device**.
