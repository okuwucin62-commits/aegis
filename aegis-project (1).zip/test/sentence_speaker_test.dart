// AEGIS — tests for the sentence-boundary logic that drives low-latency TTS.
//
// We test the pure boundary detection independently of the VoiceEngine, since
// that's the part with the trickiest edge cases (abbreviations, streaming
// fragments split mid-sentence, trailing partials).
//
// Run: flutter test test/sentence_speaker_test.dart

import 'package:flutter_test/flutter_test.dart';

/// Mirror of the boundary logic in _SentenceSpeaker for isolated testing.
class SentenceSplitter {
  final StringBuffer _buf = StringBuffer();
  final List<String> spoken = [];
  static final _boundary = RegExp(r'[.!?…]["\)\]]?\s');

  void feed(String delta) {
    _buf.write(delta);
    var text = _buf.toString();
    while (true) {
      final match = _boundary.firstMatch(text);
      if (match == null) break;
      final end = match.end;
      final sentence = text.substring(0, end).trim();
      text = text.substring(end);
      if (sentence.isNotEmpty) spoken.add(sentence);
    }
    _buf
      ..clear()
      ..write(text);
  }

  void flush() {
    final rest = _buf.toString().trim();
    if (rest.isNotEmpty) spoken.add(rest);
    _buf.clear();
  }
}

void main() {
  group('SentenceSplitter', () {
    test('emits complete sentences as they stream', () {
      final s = SentenceSplitter();
      // Simulate token-by-token streaming.
      for (final tok in ['Hello', ' there', '. ', 'How ', 'are ', 'you', '? ']) {
        s.feed(tok);
      }
      expect(s.spoken, ['Hello there.', 'How are you?']);
    });

    test('holds a partial sentence until it completes', () {
      final s = SentenceSplitter();
      s.feed('The answer is 42');
      expect(s.spoken, isEmpty); // no boundary yet
      s.feed('. Done. ');
      expect(s.spoken, ['The answer is 42.', 'Done.']);
    });

    test('flush speaks the trailing partial', () {
      final s = SentenceSplitter();
      s.feed('No terminal punctuation here');
      s.flush();
      expect(s.spoken, ['No terminal punctuation here']);
    });

    test('handles multiple terminators and ellipsis', () {
      final s = SentenceSplitter();
      s.feed('Wait... really?! ');
      expect(s.spoken, ['Wait...', 'really?!']);
    });
  });
}
