# Get the AEGIS APK on your tablet — ZIP upload, NO computer, NO folders

You upload **one file** (`aegis-project.zip`) plus create **one small text file**
(the build recipe) — both work perfectly in a tablet browser with the single-file
picker. A free cloud server then builds the APK and gives you a download link.

Time: ~15 min first time. Later rebuilds: automatic.

---

## ⚠️ Read this first (why 2 items, not 1)
GitHub only runs a build if the recipe file lives at the exact path
`.github/workflows/build-apk.yml` **in the repository**. A recipe hidden
*inside* your ZIP will NOT run. So we do two quick uploads:

1. **`aegis-project.zip`** — the app code (uploaded as a single file ✅)
2. **`.github/workflows/build-apk.yml`** — the recipe (created by typing, no
   picker needed ✅)

Both methods avoid folder selection entirely.

---

## What you need
- Your Android tablet
- A free **GitHub account** → https://github.com/signup
- Two files from this workspace, downloaded to your tablet:
  - **`aegis-project.zip`**
  - **`WORKFLOW_build-apk.yml`** (you'll copy its text)

---

## STEP 1 — Create a repository (2 min)
1. Open https://github.com on your tablet. Tip: browser menu → **Desktop site**.
2. Tap **+** (top right) → **New repository**.
3. Name it `aegis`, choose **Public**, tap **Create repository**.

---

## STEP 2 — Upload the ZIP (single file — easy) (2 min)
1. On the repo page tap **Add file** → **Upload files**.
2. Tap **choose your files** → select just **`aegis-project.zip`**.
3. Tap **Commit changes**.

✅ Only one file. The Android picker handles single files fine.

---

## STEP 3 — Add the build recipe by TYPING the path (no picker) (3 min)
This is how we place a file into `.github/workflows/` without any folder picker.

1. On the repo page tap **Add file** → **Create new file**.
2. In the **filename box at the top**, type exactly:
   ```
   .github/workflows/build-apk.yml
   ```
   (As you type each `/`, GitHub auto-creates the folders. Magic — no picker.)
3. Open **`WORKFLOW_build-apk.yml`** from this workspace, **copy ALL of its
   text**, and **paste** it into the big editor box on GitHub.
4. Scroll down, tap **Commit changes**.

---

## STEP 4 — The cloud build runs automatically (~5 min, hands-off)
1. Tap the **Actions** tab on your repo.
2. You'll see **"Build AEGIS APK"** running (yellow dot).
3. Wait for the **green check** (~4–6 min).
   - Red? Open it, tap the failed step, copy the error, send it to me.

> If it doesn't start on its own: Actions tab → **Build AEGIS APK** →
> **Run workflow** button.

---

## STEP 5 — Download your APK (1 min)
**Easiest — from Releases:**
1. Repo page → **Releases** (right side).
2. Open the newest **"AEGIS build N"**.
3. Under **Assets**, tap **AEGIS.apk** → downloads to your tablet.

**Or — from the build run:** Actions → open the green run → **Artifacts** →
**aegis-release-apk** (downloads a small zip containing AEGIS.apk).

---

## STEP 6 — Install (1 min)
1. Open the downloaded **AEGIS.apk**.
2. Allow **install from this source** if prompted → **Install**.
3. Open **AEGIS**.

---

## STEP 7 — First run
1. **Settings** → paste your OpenAI (or compatible) **API key** → **Save & verify**.
2. **Chat** to type, **Voice** to talk (grant mic permission).
3. **Tasks / Notes / Reminders** work offline with no key.

---

## Rebuilding later (still no computer)
- To change the app: replace `aegis-project.zip` (Add file → Upload files →
  commit). The build reruns automatically → new APK in **Releases**.

## What the recipe does with your ZIP
The workflow **detects `aegis-project.zip`, extracts it, finds the Flutter
project inside (works whether files are at the ZIP root or in a subfolder),
builds the release APK, and publishes it**. You never unzip anything yourself.

## If a build fails
Open the red run in **Actions**, tap the failing step, copy the log text, and
paste it to me. Cloud errors are usually a one-line dependency fix.
